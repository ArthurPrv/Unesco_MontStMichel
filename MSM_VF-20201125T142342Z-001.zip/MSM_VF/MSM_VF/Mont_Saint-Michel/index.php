<?php
header('Location: ./html/');
?>