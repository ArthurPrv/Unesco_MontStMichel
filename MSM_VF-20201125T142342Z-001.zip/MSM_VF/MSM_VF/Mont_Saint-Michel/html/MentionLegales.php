<?php
if (isset($_GET['language']) && ($_GET['language']=="en" || $_GET['language']=="fr")) {
    $language = $_GET['language'];
    $_SESSION['language']=$language;
}
elseif(isset($_SESSION['language']) && ($_SESSION['language']=="en" || $_SESSION['language']=="fr")) {
    $language=$_SESSION['language'];
}
else {
    $language = "fr";
}
?>

<!DOCTYPE html>
<html>
    <!-- head -->
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="../css/MentionLegales.css">
        <link rel="icon" type="image/png" href="../img/logoMSMPetit.png" sizes="16x16">
        <script src="TweenMax.min.js" type="text/javascript"></script>
        <title><?php echo(($language=="en") ? "Mont-Saint-Michel Website"  : "Site du Mont-Saint-Michel");?></title>
    </head>

    <!-- body -->
    <body>

        <!-- header haut de page -->
        <header>
            <?php include ('header.php')?>
            <div class="begin">
                <h1><?php echo(($language=="en") ? "Legal information"  : "Mentions Légales"); ?></h1>
            </div>
        </header>
        <?php if($language=="en"){ ?>
            <section class="rubrique">
            <h2>Legal information</h2>
            <h3>1. Presentation of the site.</h3>
            <p>In accordance with Article 6 of Law No. 2004-575 of 21 June 2004 for confidence in the digital economy, users of the site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=en"</i> are informed of the identity of the various parties involved in its implementation and monitoring:</p>
            <p><strong>Owner</strong> : Prevost Arthur –  – 7 rue des pibleus Bailly Romainvilliers<br />
            <strong>Creator</strong>  : <a href="https://etudiant.u-pem.fr/~aprevo05">Prevost Arthur</a><br />
            <strong>Publication manager</strong> : Tewfik Ettayeb – ettayebtewfik@gmail.com<br />
            The person responsible for publication is a natural person or a legal entity.<br />
            <strong>Webmaster</strong> : Gregoire Petetin – gregoire.petetin@gmail.com<br />
            <strong>Hosting</strong> : OVH – 2 rue Kellermann – BP 80157 59053 ROUBAIX CEDEX 1<br />
            Credits : Lucas TRIPIER, Thomas VEXIAU, Gregoire PETETIN, Killian PELLETIER<br />
            The legal notice template is offered by Subdelirium.com <a target="_blank" href="https://www.subdelirium.com/generateur-de-mentions-legales/" alt="generateur de mentions légales">Legal notice generator</a></p>

            <h3>2. General conditions of use of the site and services offered.</h3>
                <p>The use of the site  <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=en/"</i> implies full acceptance of the general conditions of use described below. These terms of use may be modified or supplemented at any time, users of the site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=en/"</i> are therefore invited to consult them regularly.</p>
            <p>This site is normally accessible to users at all times. However, Prevost Arthur may decide to interrupt the service for technical maintenance, in which case Prevost Arthur will endeavour to inform users in advance of the dates and times of the intervention.</p>
                <p>The website <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=en/"</i> is regularly updated by Tewfik Ettayeb. In the same way, the legal notices may be modified at any time: they are nevertheless binding on the user, who is invited to refer to them as often as possible in order to read them.</p>
            
            <h3>3. Description of services provided.</h3>
            <p>The website <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=en/"</i> is intended to provide information about all the company's activities.</p>
                <p>Prevost Arthur strives to provide on the site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=en/"</i> Iformation that is as accurate as possible. However, it cannot be held responsible for omissions, inaccuracies and shortcomings in the update, whether caused by itself or by the third party partners who provide it with this information.</p>
                <p>All the information indicated on the site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=en/"</i> s given as an indication, and is likely to evolve. Moreover, the information on the site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=en/"</i> is not exhaustive. They are given subject to modifications that have been made since they were put online.</p>
            
            <h3>4. Contractual limitations on technical data.</h3>
            <p>The site uses JavaScript technology.</p>
            <p>The website cannot be held responsible for any material damage related to the use of the site. In addition, the user of the site undertakes to access the site using recent, virus-free equipment and a latest-generation, up-to-date browser.</p>
            
            <h3>5. Intellectual property and counterfeits.</h3>
            <p>Prevost Arthur  is the owner of the intellectual property rights or holds the rights to use all the elements accessible on the site, in particular the texts, images, graphics, logo, icons, sounds and software.</p>
            <p>Any reproduction, representation, modification, publication, adaptation of all or part of the elements of the site, regardless of the means or process used, is prohibited without the prior written permission of : Prevost Arthur.</p>
            <p>Any unauthorised use of the site or any of the elements it contains will be considered as an infringement and will be prosecuted in accordance with the provisions of articles L.335-2 and following of the Intellectual Property Code.</p>
            
            <h3>6. Limitations of liability.</h3>
            <p>Prevost Arthur cannot be held liable for direct or indirect damage caused to the user's equipment when accessing the  https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=en,and resulting either from the use of equipment that does not meet the specifications indicated in point 4, or from the appearance of a bug or incompatibility.</p>
                <p>Prevost Arthur shall also not be liable for indirect damages (such as loss of business or loss of opportunity) resulting from the use of the <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=en/"</i> website.</p>
            <p>Interactive spaces (possibility to ask questions in the contact area) are available to users. Prevost Arthur reserves the right to delete, without prior notice, any content posted in this space that contravenes the legislation applicable in France, in particular the provisions relating to data protection. Where appropriate, Prevost Arthur also reserves the right to hold the user liable under civil and/or criminal law, in particular in the event of a racist, insulting, defamatory or pornographic message, regardless of the medium used (text, photograph, etc.).</p>
            
            <h3>7. Management of personal data.</h3>
            <p>In France, personal data is notably protected by law n° 78-87 of January 6, 1978, law n° 2004-801 of August 6, 2004, article L. 226-13 of the Penal Code and the European Directive of October 24, 1995.</p>
                <p>On the occasion of the use of the site  <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=en/"</i>, may be collected: the URL of the links through which the user accessed the site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=en/"</i>, the user's access provider, the user's Internet Protocol (IP) address.</p>
                <p> In any event, Prevost Arthur only collects personal information relating to the user for the purpose of certain services offered by the <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=en/"</i> website. The user provides this information with full knowledge of the facts, particularly when he enters it himself. It is then specified to the user of the site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=en/"</i> the obligation or not to provide this information.</p>
            <p>In accordance with the provisions of articles 38 and following of law 78-17 of 6 January 1978 relating to data processing, files and liberties, any user has the right to access, rectify and oppose personal data concerning him/her, by making a written and signed request, accompanied by a copy of the identity document with the signature of the holder, specifying the address to which the reply should be sent.</p>
                <p>No personal information of the user of the site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=en/"</i> is published without the user's knowledge, exchanged, transferred, ceded or sold on any medium whatsoever to third parties. Only the hypothesis of the purchase of Prevost Arthur and its rights would allow the transmission of the said information to the potential purchaser who would in turn be bound by the same obligation to preserve and modify the data with regard to the user of the site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=en/"</i>.</p>
            <p>The databases are protected by the provisions of the Law of 1 July 1998 transposing Directive 96/9 of 11 March 1996 on the legal protection of databases./p>
            
            <h3>8. Hypertext links and cookies.</h3>
                <p>The site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=en/"</i> contains a number of hypertext links to other sites, set up with the authorisation of Prevost Arthur. However, Prevost Arthur is not able to verify the content of the sites visited in this way, and consequently assumes no responsibility for this fact.</p>
                <p>Browsing the site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=en/"</i> is likely to cause the installation of cookie(s) on the user's computer. A cookie is a small file, which does not allow the identification of the user, but which records information relating to the navigation of a computer on a site. The data obtained in this way is intended to facilitate subsequent navigation on the site, and is also intended to enable various measures of traffic</p>
            <p>Refusal to install a cookie may result in the inability to access certain services. However, the user can configure his or her computer as follows to refuse the installation of cookies:</p>
            <p>Under Internet Explorer: tool tab (gear icon in the top right corner) / internet options. Click Privacy and choose Block all cookies. Validate on Ok.</p>
            <p>Under Firefox: at the top of the browser window, click on the Firefox button, then go to the Options tab. Click on the Privacy tab. Set the Retention Rules to: Use custom settings for history. Finally uncheck it to disable cookies.</p>
            <p>Under Safari: Click on the menu pictogram (symbolized by a cog) at the top right of the browser. Choose Settings. Click Show Advanced Settings. In the "Privacy" section, click on Content Settings. In the "Cookies" section, you can block cookies.</p>
            <p>Under Chrome: Click on the menu icon (symbolized by three horizontal lines) at the top right of the browser. Choose Settings. Click Show Advanced Settings. In the "Privacy" section, click on preferences. In the "Privacy" tab, you can block cookies.</p>

            <h3>9. Applicable law and jurisdiction.</h3>
                <p>Any dispute in connection with the use of the site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=en/"</i> is subject to French law. Exclusive jurisdiction is given to the competent courts of Paris.</p>
            
            <h3>10. The main laws concerned.</h3>
            <p>Law n° 78-17 of 6 January 1978, notably modified by law n° 2004-801 of 6 August 2004 relating to data processing, files and liberties.</p>
            <p>Law No. 2004-575 of 21 June 2004 for confidence in the digital economy.</p>
            
            <h3>11. Lexicon.</h3>
            <p>User: Internet user connecting, using the above-mentioned site.</p>
            <p>Personal information: "information that allows, in any form whatsoever, directly or indirectly, the identification of the natural persons to which it applies" (article 4 of the law n° 78-17 of January 6, 1978).</p>

            <h3>12. Related Documents</h3>
            <p> <a target="_blank"  href="../Presentation_Forum_UNESCO_anglais.pdf">Forum Unesco Presentation</a></p>

            </section>

        <?php }else{ ?>

        <section class="rubrique">
            <h2>Informations légales</h2>
            <h3>1. Présentation du site.</h3>
            <p>En vertu de l'article 6 de la loi n° 2004-575 du 21 juin 2004 pour la confiance dans l'économie numérique, il est précisé aux utilisateurs du site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=fr/"</i> l'identité des différents intervenants dans le cadre de sa réalisation et de son suivi :</p>
            <p><strong>Propriétaire</strong> : Prevost Arthur –  – 7 rue des pibleus Bailly Romainvilliers<br />
            <strong>Créateur</strong>  : <a href="https://etudiant.u-pem.fr/~aprevo05">Prevost Arthur</a><br />
            <strong>Responsable publication</strong> : Tewfik Ettayeb – ettayebtewfik@gmail.com<br />
            Le responsable publication est une personne physique ou une personne morale.<br />
            <strong>Webmaster</strong> : Gregoire Petetin – gregoire.petetin@gmail.com<br />
            <strong>Hébergeur</strong> : OVH – 2 rue Kellermann – BP 80157 59053 ROUBAIX CEDEX 1<br />
            Crédits : Lucas TRIPIER, Thomas VEXIAU, Gregoire PETETIN, Killian PELLETIER<br />
            Le modèle de mentions légales est offert par Subdelirium.com <a target="_blank" href="https://www.subdelirium.com/generateur-de-mentions-legales/" alt="generateur de mentions légales">Générateur de mentions légales</a></p>

            <h3>2. Conditions générales d’utilisation du site et des services proposés.</h3>
            <p>L’utilisation du site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=fr/"</i> implique l’acceptation pleine et entière des conditions générales d’utilisation ci-après décrites. Ces conditions d’utilisation sont susceptibles d’être modifiées ou complétées à tout moment, les utilisateurs du site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=fr/"</i> sont donc invités à les consulter de manière régulière.</p>
            <p>Ce site est normalement accessible à tout moment aux utilisateurs. Une interruption pour raison de maintenance technique peut être toutefois décidée par Prevost Arthur, qui s’efforcera alors de communiquer préalablement aux utilisateurs les dates et heures de l’intervention.</p>
            <p>Le site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=fr/"</i> est mis à jour régulièrement par Tewfik Ettayeb. De la même façon, les mentions légales peuvent être modifiées à tout moment : elles s’imposent néanmoins à l’utilisateur qui est invité à s’y référer le plus souvent possible afin d’en prendre connaissance.</p>
            <h3>3. Description des services fournis.</h3>
            <p>Le site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=fr/"</i> a pour objet de fournir une information concernant l’ensemble des activités de la société.</p>
            <p>Prevost Arthur s’efforce de fournir sur le site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=fr/"</i> des informations aussi précises que possible. Toutefois, il ne pourra être tenue responsable des omissions, des inexactitudes et des carences dans la mise à jour, qu’elles soient de son fait ou du fait des tiers partenaires qui lui fournissent ces informations.</p>
            <p>Tous les informations indiquées sur le site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=fr/"</i> sont données à titre indicatif, et sont susceptibles d’évoluer. Par ailleurs, les renseignements figurant sur le site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=fr/"</i> ne sont pas exhaustifs. Ils sont donnés sous réserve de modifications ayant été apportées depuis leur mise en ligne.</p>
            <h3>4. Limitations contractuelles sur les données techniques.</h3>
            <p>Le site utilise la technologie JavaScript.</p>
            <p>Le site Internet ne pourra être tenu responsable de dommages matériels liés à l’utilisation du site. De plus, l’utilisateur du site s’engage à accéder au site en utilisant un matériel récent, ne contenant pas de virus et avec un navigateur de dernière génération mis-à-jour</p>
            <h3>5. Propriété intellectuelle et contrefaçons.</h3>
            <p>Prevost Arthur est propriétaire des droits de propriété intellectuelle ou détient les droits d’usage sur tous les éléments accessibles sur le site, notamment les textes, images, graphismes, logo, icônes, sons, logiciels.</p>
            <p>Toute reproduction, représentation, modification, publication, adaptation de tout ou partie des éléments du site, quel que soit le moyen ou le procédé utilisé, est interdite, sauf autorisation écrite préalable de : Prevost Arthur.</p>
            <p>Toute exploitation non autorisée du site ou de l’un quelconque des éléments qu’il contient sera considérée comme constitutive d’une contrefaçon et poursuivie conformément aux dispositions des articles L.335-2 et suivants du Code de Propriété Intellectuelle.</p>
            <h3>6. Limitations de responsabilité.</h3>
            <p>Prevost Arthur ne pourra être tenue responsable des dommages directs et indirects causés au matériel de l’utilisateur, lors de l’accès au site https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=fr, et résultant soit de l’utilisation d’un matériel ne répondant pas aux spécifications indiquées au point 4, soit de l’apparition d’un bug ou d’une incompatibilité.</p>
            <p>Prevost Arthur ne pourra également être tenue responsable des dommages indirects (tels par exemple qu’une perte de marché ou perte d’une chance) consécutifs à l’utilisation du site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=fr/"</i>.</p>
            <p>Des espaces interactifs (possibilité de poser des questions dans l’espace contact) sont à la disposition des utilisateurs. Prevost Arthur se réserve le droit de supprimer, sans mise en demeure préalable, tout contenu déposé dans cet espace qui contreviendrait à la législation applicable en France, en particulier aux dispositions relatives à la protection des données. Le cas échéant, Prevost Arthur se réserve également la possibilité de mettre en cause la responsabilité civile et/ou pénale de l’utilisateur, notamment en cas de message à caractère raciste, injurieux, diffamant, ou pornographique, quel que soit le support utilisé (texte, photographie…).</p>
            <h3>7. Gestion des données personnelles.</h3>
            <p>En France, les données personnelles sont notamment protégées par la loi n° 78-87 du 6 janvier 1978, la loi n° 2004-801 du 6 août 2004, l'article L. 226-13 du Code pénal et la Directive Européenne du 24 octobre 1995.</p>
            <p>A l'occasion de l'utilisation du site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=fr/"</i>, peuvent êtres recueillies : l'URL des liens par l'intermédiaire desquels l'utilisateur a accédé au site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=fr/"</i>, le fournisseur d'accès de l'utilisateur, l'adresse de protocole Internet (IP) de l'utilisateur.</p>
            <p> En tout état de cause Prevost Arthur ne collecte des informations personnelles relatives à l'utilisateur que pour le besoin de certains services proposés par le site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=fr/"</i>. L'utilisateur fournit ces informations en toute connaissance de cause, notamment lorsqu'il procède par lui-même à leur saisie. Il est alors précisé à l'utilisateur du site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=fr/"</i> l’obligation ou non de fournir ces informations.</p>
            <p>Conformément aux dispositions des articles 38 et suivants de la loi 78-17 du 6 janvier 1978 relative à l’informatique, aux fichiers et aux libertés, tout utilisateur dispose d’un droit d’accès, de rectification et d’opposition aux données personnelles le concernant, en effectuant sa demande écrite et signée, accompagnée d’une copie du titre d’identité avec signature du titulaire de la pièce, en précisant l’adresse à laquelle la réponse doit être envoyée.</p>
            <p>Aucune information personnelle de l'utilisateur du site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=fr/"</i> n'est publiée à l'insu de l'utilisateur, échangée, transférée, cédée ou vendue sur un support quelconque à des tiers. Seule l'hypothèse du rachat de Prevost Arthur et de ses droits permettrait la transmission des dites informations à l'éventuel acquéreur qui serait à son tour tenu de la même obligation de conservation et de modification des données vis à vis de l'utilisateur du site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=fr/"</i>.</p>
            <p>Les bases de données sont protégées par les dispositions de la loi du 1er juillet 1998 transposant la directive 96/9 du 11 mars 1996 relative à la protection juridique des bases de données.</p>
            <h3>8. Liens hypertextes et cookies.</h3>
            <p>Le site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=fr/"</i> contient un certain nombre de liens hypertextes vers d’autres sites, mis en place avec l’autorisation de Prevost Arthur. Cependant, Prevost Arthur n’a pas la possibilité de vérifier le contenu des sites ainsi visités, et n’assumera en conséquence aucune responsabilité de ce fait.</p>
            <p>La navigation sur le site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=fr/"</i> est susceptible de provoquer l’installation de cookie(s) sur l’ordinateur de l’utilisateur. Un cookie est un fichier de petite taille, qui ne permet pas l’identification de l’utilisateur, mais qui enregistre des informations relatives à la navigation d’un ordinateur sur un site. Les données ainsi obtenues visent à faciliter la navigation ultérieure sur le site, et ont également vocation à permettre diverses mesures de fréquentation.</p>
            <p>Le refus d’installation d’un cookie peut entraîner l’impossibilité d’accéder à certains services. L’utilisateur peut toutefois configurer son ordinateur de la manière suivante, pour refuser l’installation des cookies :</p>
            <p>Sous Internet Explorer : onglet outil (pictogramme en forme de rouage en haut a droite) / options internet. Cliquez sur Confidentialité et choisissez Bloquer tous les cookies. Validez sur Ok.</p>
            <p>Sous Firefox : en haut de la fenêtre du navigateur, cliquez sur le bouton Firefox, puis aller dans l'onglet Options. Cliquer sur l'onglet Vie privée.
            Paramétrez les Règles de conservation sur :  utiliser les paramètres personnalisés pour l'historique. Enfin décochez-la pour  désactiver les cookies.</p>
            <p>Sous Safari : Cliquez en haut à droite du navigateur sur le pictogramme de menu (symbolisé par un rouage). Sélectionnez Paramètres. Cliquez sur Afficher les paramètres avancés. Dans la section "Confidentialité", cliquez sur Paramètres de contenu. Dans la section "Cookies", vous pouvez bloquer les cookies.</p>
            <p>Sous Chrome : Cliquez en haut à droite du navigateur sur le pictogramme de menu (symbolisé par trois lignes horizontales). Sélectionnez Paramètres. Cliquez sur Afficher les paramètres avancés. Dans la section "Confidentialité", cliquez sur préférences.  Dans l'onglet "Confidentialité", vous pouvez bloquer les cookies.</p>

            <h3>9. Droit applicable et attribution de juridiction.</h3>
            <p>Tout litige en relation avec l’utilisation du site <i>"http://https://etudiant.u-pem.fr/~ltripier/MSM/html/MentionLegales.php?language=fr/"</i> est soumis au droit français. Il est fait attribution exclusive de juridiction aux tribunaux compétents de Paris.</p>
            <h3>10. Les principales lois concernées.</h3>
            <p>Loi n° 78-17 du 6 janvier 1978, notamment modifiée par la loi n° 2004-801 du 6 août 2004 relative à l'informatique, aux fichiers et aux libertés.</p>
            <p> Loi n° 2004-575 du 21 juin 2004 pour la confiance dans l'économie numérique.</p>
            <h3>11. Lexique.</h3>
            <p>Utilisateur : Internaute se connectant, utilisant le site susnommé.</p>
            <p>Informations personnelles : « les informations qui permettent, sous quelque forme que ce soit, directement ou non, l'identification des personnes physiques auxquelles elles s'appliquent » (article 4 de la loi n° 78-17 du 6 janvier 1978).</p>


            <h3>12. Documents Associés</h3>
            <a target="_blank" href="../Presentation_Forum_UNESCO_francais.pdf">Présentation Forum Unesco</a>
        </section>

        <?php } ?>

        <footer>
            <?php include ('footer.php')?>
        </footer>

        <div id="scroll_to_top"  class="fleche"> 
            <a href="#top"><img src="../img/top.png" alt="Retourner en haut" /></a> 
        </div>
    </body>
</html>