<?php
if (isset($_GET['language']) && ($_GET['language']=="en" || $_GET['language']=="fr")) {
    $language = $_GET['language'];
    $_SESSION['language']=$language;
}
elseif(isset($_SESSION['language']) && ($_SESSION['language']=="en" || $_SESSION['language']=="fr")) {
    $language=$_SESSION['language'];
}
else {
    $language = "fr";
}
?>

<!DOCTYPE html>
<html>
    <!-- head -->
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="../css/Accueil_2.0.css">
        <link rel="icon" type="image/png" href="../img/logoMSMPetit.png" sizes="16x16">
        <script src="TweenMax.min.js" type="text/javascript"></script>
        <title><?php echo(($language=="en") ? "Mont-Saint-Michel Website"  : "Site du Mont-Saint-Michel");?></title>
    </head>

    <!-- body -->
    <body>

        <!-- header haut de page -->
        <header>
            <?php include ('header.php')?>


            <div class="begin">
                
                <h1>Mont Saint Michel</h1>
            </div>

        </header>

        <?php if($language=="en"){?>
            <section id="onglets">

                <h2>Discover:</h2>
                <hr>

                <div class="section_container">
                    <div class="first-row">
                        <div class="decouverte cocktail-item col-2">
                            <a href=<?php echo ("../html/Histoire.php?language=".$language) ?> class="lien"><h4>History</h4>
                                <div class="overlay">
                                    <img src="../img/histoire.jpg">
                                    <h4>History</h4>
                                    <hr class="hroverlay">
                                    <p>Discover the history behind this cultural heritage. From its creation to today, relive its extraordinary adventure.</p>
                                </div>
                        </div></a>

                        <div class="restaurant cocktail-item col-2">
                            <a href=<?php echo ("../html/Architecture.php?language=".$language) ?> class="lien"><h4>Architecture</h4>
                                <div class="overlay">
                                    <img src="../img/architecture_2.jpg">
                                    <h4>Architecture</h4>
                                    <hr class="hroverlay">
                                    <p>Explore every nook and cranny of Mont-Saint-Michel. How was it founded, with what materials? Here you'll get your answer.</p>
                                </div>
                        </div></a>
                    </div>

                    <div class="second-row">
                        <div class="maison cocktail-item col-2">
                            <a href=<?php echo ("../html/Religion.php?language=".$language) ?> class="lien"><h4>Religion</h4>
                                <div class="overlay">
                                    <img src="../img/maison.jpg"/>
                                    <h4>Religion</h4>
                                    <hr class="hroverlay">
                                    <p>Before thinking of Mont-Saint-Michel as a tourist destination, we must not forget that it is above all a place of pilgrimage. Discover here the whole Mont-Saint-Michel's religious history</p>
                                </div>
                        </div></a>

                        <div class="transports cocktail-item col-2">
                            <a href=<?php echo ("../html/InfosUtiles.php?language=".$language) ?> class="lien"><h4>Useful&nbspInfos</h4>
                                <div class="overlay">
                                    <img src="../img/transports.jpg"/>
                                    <h4>Useful&nbspInfos</h4>
                                    <hr class="hroverlay">
                                    <p>Here you will find all the little anecdotes and information about the Mount: Mont's statistics, Transport to come, etc...</p>
                                </div>
                        </div></a>

                    </div>
                </div>


            </section>



            <!-- section Groupe -->

            <div class="Famillediv">
                <h2 class="famille">You are coming:</h2>
                <hr class="famillehr">
                <section id="Famille">

                    <div>
                        <a href=<?php echo ("../html/Groupe.php?language=".$language) ?>#seul><img src="../img/Seul.png" class="rond"></a>
                        <p>Alone</p>
                    </div>
                    <div>
                        <a href=<?php echo ("../html/Groupe.php?language=".$language) ?>#famille><img src="../img/Groupe.png" class="rond"></a>
                        <p>With Family</p>
                    </div>
                    <div >
                        <a href=<?php echo ("../html/Groupe.php?language=".$language) ?>#amis><img src="../img/Groupe.png" class="rond"></a>
                        <p>With Friends</p>
                    </div>
                    <div >
                        <a href=<?php echo ("../html/Groupe.php?language=".$language) ?>#scolaire><img src="../img/Couple.png" class="rond"></a>
                        <p>Scolar Group</p>
                    </div>
                </section>
            </div>



            <!-- section Localisation et Réseaux Sociaux -->
            <section id="Map">

                <div class="map">
                    <h3>Location</h3>
                    <hr class="hrmap">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d42185.82719777353!2d-1.5637363334136647!3d48.63636429205669!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x480ea8d67c9ceeb3%3A0xc5834ce47e0dc3fe!2s50170%20Le%20Mont-Saint-Michel!5e0!3m2!1sfr!2sfr!4v1587749973932!5m2!1sfr!2sfr" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0" class="map"></iframe>
                </div>
            </section>

            <section id="reseaux">
                <div class="titreres">
                    <h3 class="res">Social networks</h3>
                    <hr class="hrres>">
                </div>
                <div class="iconer">
                    <a target="_blank " href="https://twitter.com/Mont_StMichel"><img src="../img/twitter.png"  class="twitter"></a>
                    <a target="_blank " href="https://www.facebook.com/Tourisme.montsaintmichel/"><img src="../img/Facebook.png"  class="facebook"></a>
                    <a target="_blank" href="https://www.instagram.com/mont_stmichel/"><img src="../img/Insta.png" class="insta"></a>
                </div>
            </section>


        <?php }else{ ?>

        <!-- section onglets -->
        <section id="onglets">

            <h2>Découvrez:</h2>
            <hr>

            <div class="section_container">
                <div class="first-row">
                    <div class="decouverte cocktail-item col-2">
                        <a href=<?php echo ("../html/Histoire.php?language=".$language) ?>  class="lien"><h4>L'Histoire</h4>
                        <div class="overlay">
                            <img src="../img/histoire.jpg">
                            <h4>Histoire</h4>
                            <hr class="hroverlay">
                            <p>Découvrez l'histoire qui se cache derrière ce patrimoine culturelle. De sa création jusqu'à aujourd'hui, revivez son aventure extraordinaire</p>
                        </div>
                    </div></a>
        
                    <div class="restaurant cocktail-item col-2">
                        <a href=<?php echo ("../html/Architecture.php?language=".$language) ?>  class="lien"><h4>L'Architecture</h4>
                        <div class="overlay">
                            <img src="../img/architecture_2.jpg">
                            <h4>Architecture</h4>
                            <hr class="hroverlay">
                            <p>Explorez le Mont-Saint-Michel dans ses moindres recoins. Comment a-t-il été fondé, avec quelles matériaux ? Ici vous aurez votre réponse.</p>
                        </div>
                    </div></a>
                </div>
    
                <div class="second-row">
                    <div class="maison cocktail-item col-2">
                        <a href=<?php echo ("../html/Religion.php?language=".$language) ?>  class="lien"><h4>La Religion</h4>
                        <div class="overlay">
                            <img src="../img/maison.jpg"/>
                            <h4>Religion</h4>
                            <hr class="hroverlay">
                            <p>Avant de penser au Mont-Saint-Michel en tant que lieu touristique, il ne faut pas oublier que c'est avant tout un lieu de pelerinage. Découvrez ici toute l'histoire religieuse du Mont-Saint-Michel-au-péril-de-la-Mer</p>
                        </div>
                    </div></a>
        
                    <div class="transports cocktail-item col-2">
                        <a href=<?php echo ("../html/InfosUtiles.php?language=".$language) ?>  class="lien"><h4>Les Infos Utiles</h4>
                        <div class="overlay">
                            <img src="../img/transports.jpg"/>
                            <h4>Infos Utiles</h4>
                            <hr class="hroverlay">
                            <p>Ici retrouvez toutes les petites anecdotes, informations sur le Mont: Le Mont en Chiffre, les Transports pour venir, etc...</p>
                        </div>
                    </div></a>
    
                </div>
            </div>


        </section>
        


        <!-- section Groupe -->
        
        <div class="Famillediv">
        <h2 class="famille">Vous venez:</h2>
        <hr class="famillehr">
        <section id="Famille">

            <div>
                <a href=<?php echo ("../html/Groupe.php?language=".$language) ?>#seul><img src="../img/Seul.png" class="rond" width="85%"></a>
                <p>Tout seul</p>
            </div>
            <div>
                <a href=<?php echo ("../html/Groupe.php?language=".$language) ?>#famille><img src="../img/Groupe.png" class="rond"></a>
                <p>En Famille</p>
            </div>
            <div >
                <a href=<?php echo ("../html/Groupe.php?language=".$language) ?>#amis><img src="../img/Groupe.png" class="rond"></a>
                <p>Entre Amis</p>
            </div>
            <div >
                <a href=<?php echo ("../html/Groupe.php?language=".$language) ?>#scolaire><img src="../img/Couple.png" class="rond"></a>
                <p>Groupe scolaire</p>
            </div>
        </section>
        </div>



        <!-- section Localisation et Réseaux Sociaux -->
        <section id="Map">
        
            <div class="map">
                <h3>Localisation</h3>
                <hr class="hrmap">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d42185.82719777353!2d-1.5637363334136647!3d48.63636429205669!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x480ea8d67c9ceeb3%3A0xc5834ce47e0dc3fe!2s50170%20Le%20Mont-Saint-Michel!5e0!3m2!1sfr!2sfr!4v1587749973932!5m2!1sfr!2sfr" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0" class="map"></iframe>
            </div> 
        </section>

        <section id="reseaux">
            <div class="titreres">
                <h3 class="res">Réseaux Sociaux</h3>
                <hr class="hrres>">
            </div>
            <div class="iconer">
                <a target="_blank" href="https://twitter.com/Mont_StMichel"><img src="../img/twitter.png"  class="twitter"></a>
                <a target="_blank"  href="https://www.facebook.com/Tourisme.montsaintmichel/"><img src="../img/Facebook.png"  class="facebook"></a>
                <a target="_blank" href="https://www.instagram.com/mont_stmichel/"><img src="../img/Insta.png" class="insta"></a>
            </div>
        </section>

        <?php } ?>

        <!-- pied de page -->
        <footer>
            <?php include ('footer.php')?>
        </footer>

        <div id="scroll_to_top"  class="fleche"> 
            <a href="#top"><img src="../img/top.png" alt="Retourner en haut" /></a> 
        </div>
    </body>
</html>