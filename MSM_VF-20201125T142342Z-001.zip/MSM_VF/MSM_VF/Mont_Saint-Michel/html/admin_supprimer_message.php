<?php
session_start();
if(!isset($_SESSION['login'])){
    header('Location: admin_connexion.html');
    exit;
}
if(!isset($_GET['numContact'])){
    header('Location: admin_afficher_contacts.php');
    exit;
}
include('connexion.php');
$numContact = $_GET['numContact'];
$requete = "Delete From msm_contact Where numContact = $numContact";
$dbh->exec($requete);
header('Location: admin_afficher_contacts.php');
exit;
?>