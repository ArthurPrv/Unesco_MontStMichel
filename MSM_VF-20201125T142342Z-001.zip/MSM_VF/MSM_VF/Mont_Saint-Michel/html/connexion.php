<!DOCTYPE html>
<html>
<body>

<?php
/* Connexion au serveur et à la base de données */
$host="sqletud.u-pem.fr";
$user="gpetetin"; /* Votre login */
$pwd="Vaugre1214"; /* Votre mot de passe */
$db="gpetetin_db"; /* Le nom de votre base : de la forme ici : xxx_db avec xxx votre login */
    // Connexion avec avec PDO
try{
$con = "mysql:host=$host;dbname=$db";
$dbh = new PDO($con,$user,$pwd);
$dbh->exec('SET NAMES utf8');
 }
catch(Exception $e){
die('Connexion impossible à la base de données !'.$e->getMessage());
}
?>

</body></html>