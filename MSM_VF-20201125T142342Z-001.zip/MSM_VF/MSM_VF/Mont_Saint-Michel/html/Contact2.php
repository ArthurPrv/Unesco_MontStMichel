<?php 

if(!isset($_POST['nom'])){
    header('Location: Contact.php');
    exit;
}
include('connexion.php');

$prenom = $_POST['prenom'];
$nom = $_POST['nom'];
$mail = $_POST['mail'];
$message = $_POST['message'];

$date = date("Y-m-d");
$requete = "Insert into msm_contact Values(NULL, '$prenom', '$nom', '$mail', \"$message\", '$date', 0);";
echo $requete;
$dbh->exec($requete);
mail("montsaintmichelunesco@gmail.com","MSM : Nouveau message depuis le formulaire","$prenom $nom a envoyé(e) un nouveau message :\nMessage :\n $message \n\n");

?>