<?php
if (isset($_GET['language']) && ($_GET['language']=="en" || $_GET['language']=="fr")) {
    $language = $_GET['language'];
    $_SESSION['language']=$language;
}
elseif(isset($_SESSION['language']) && ($_SESSION['language']=="en" || $_SESSION['language']=="fr")) {
    $language=$_SESSION['language'];
}
else {
    $language = "fr";
}
?>


<!DOCTYPE html>
<html>
    <head>

        <meta charset="UTF-8">
        <title><?php echo ($language=="en") ? "Useful Information" : "Infos Utiles" ?></title>
        <link rel="stylesheet" type="text/css" href="../css/InfosUtiles.css">
        <link rel="icon" type="image/png" href="../img/logoMSMPetit.png" sizes="16x16">
    </head>
    <?php include ('header.php')?>
    <?php if($language=="en"){ ?>
        <body>
        <div class="begin">
            <h1>Useful Informations</h1>
        </div>

        <div class="sommaire3">
            <span class="sommaire2"><a href=<?php echo ("../html/index.php?language=".$language) ?>>Home &nbsp </a> >
            <a href=<?php echo ("../html/InfosUtiles.php?language=".$language) ?>>&nbsp Useful Infos</a></span>
        </div>

        <section class="transport">
            <h3>Transport</h3>
            <h4>To access at the Month</h4>
            <p>
                ->on foot : ~50 min from the car park to the footbridge<br> 
                To do so, 3 routes are available:<br>
                1. The East route: The Edge, accessible to all<br> 
                2. The West route: The banks of the Couesnon, passing through the dam of the Mont Saint Michel bay.<br>
                3. The Central route: "Mont-Saint-Michel", passing through the place called Mont Saint Michel, restaurants, accommodation, supermarket, etc.<br>
            </p>
            <h4>From the footbridge to the mountain:</h4>
            <p>
                -On foot or by free access shuttle bus "Le passeur".<br>
                The ferryman is a reversible shuttle (two driving stations) available from 7:30 am to 00:00 am.<br>
                ~12minutes of travel, deposit at 300m from the ramparts of the Mount.<br>
                Other possibility: horse-drawn shuttle "La Maringote", towed by two draught horses ~25 minutes.<br>
            </p>
            <br>
            <h3>IMPORTANT BEFORE THE VISIT:</h3>
            <p>-To reach the mount and the abbey, a lot of walking is to be expected.<br>
                -Bags smaller than the cabin size are allowed, not the rest.<br>
                -All types of animals are forbidden, even if transported in a bag (Nevertheless guide dogs and assistance dogs are allowed).<br> </span>
                -The carrying of knives and the use of scooters is prohibited within the Mont Blanc enclosure.<br>
                -It is forbidden to smoke in the monument<br>
                -Access to the abbey is very difficult for PRMs as there are many steps.<br>
                -Access to the Mount is forbidden for minors who are not accompanied by a responsible person.<br>
            </p>
            <br>
            <a href=<?php echo ("../html/Groupe.php?language=".$language) ?>><h2>Prepare your visit</h2>


        </section>


        <div id="scroll_to_top"  class="fleche">
            <a href="#top"><img src="../img/top.png" alt="Retourner en haut" /></a>
        </div>
        </body>
    <?php }else{ ?>
    <body>

    <div class="begin">
        <h1>Informations Utiles</h1>
    </div>

        <div class="sommaire3"> 
            <span class="sommaire2"><a href=<?php echo ("../html/index.php?language=".$language) ?>>Accueil &nbsp</a> >
               <a href=<?php echo ("../html/InfosUtiles.php?language=".$language) ?>>&nbsp Infos Utiles</a></span>
        </div>

        <section class="transport">
            <h3>Transport</h3>
            <h4>Pour accéder au mont:</h4>
            <p>
                ->à pieds : ~50 min du parking à la passerelle<br>
                Pour ce faire, 3 trajets disponible:<br>
                1. Le parcours Est: La Lisière, accessible à tous<br>
                2. Le parcours Ouest: Les berges du Couesnon, passage par le barrage de la baie du Mont Saint Michel<br>
                3. Le parcours Central: "Mont-Saint-Michel", passage par le lieu dit Mont Saint Michel, restaurants, hébergements, supermarché<br>
                <br>
             </p>
            <h4>De la passerelle au mont :</h4>
            <p>
                -A pied ou par navette en accès libre "Le passeur"<br>
                Le passeur est une navette reversible (deux postes de conduite) dispo de 7h30 jusqu'à 00h<br>
                ~12minutes de trajets,depose à 300m des remparts du Mont<br> </span>
                Autre possibilité : navette hippomobile "La Maringote",tracté par deux chevaux de traits ~25 minutes<br>
            </p>
            <br>
            <h3>IMPORTANT AVANT LA VISITE:</h3>
                <p>-Pour accéder au mont et à l’abbaye, beaucoup de marche est à prévoir<br>
                -Les sacs d’une dimensions inférieur au format cabine sont autorisés, pas le reste<br>
                -Tout types d’animaux sont interdits, même transportés dans un sac (Néanmoins chien guide et d’assistance à la personne autorisés)<br> </span>
                -Le port d’arme blanche et l'usage de trottinette est interdit dans l'enceinte du Mont<br>
                -Il est interdit de fumer dans le monument<br>
                -L’accès à l'abbaye est très difficile pour les PMR car il y a beaucoup de marches<br>
                -L’accès au Mont est interdit pour les mineurs non accompagnés d’un responsable<br>
                </p>
                <br>
            <a href=<?php echo ("../html/Groupe.php?language=".$language) ?>><h2>Preparez votre visite</h2>
        </section>


        <div id="scroll_to_top"  class="fleche"> 
            <a href="#top"><img src="../img/top.png" alt="Retourner en haut" /></a> 
        </div>
    </body>
    <?php }
    include('footer.php');
    ?>
</html>