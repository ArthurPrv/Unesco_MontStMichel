<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/Contact.css">
    <title>Messages</title>
</head>
<body>
<h1>Administration</h1>
<a href="deconnexion.php"><button>Déconnexion</button></a>

<?php
session_start();
if(!isset($_SESSION['login'])){
    header('Location: admin_connexion.html');
}
include('connexion.php');
if(isset($_GET['OrderBy']) && in_array($_GET['OrderBy'], array("numContact", "nom", "prenom", "mail", "message", "date", "statut") )){
    $OrderBy = $_GET['OrderBy'];
}
else {
   $OrderBy = "numContact"; 
}
$requete = "Select * From msm_contact Order By $OrderBy";
$resultat = $dbh->query($requete);
$i = 0;
?>
<table>
    <thead>
        <th><a href="admin_afficher_contacts.php?OrderBy=numContact">Numéro</a></th>
        <th><a href="admin_afficher_contacts.php?OrderBy=prenom">Prénom</a></th>
        <th><a href="admin_afficher_contacts.php?OrderBy=nom">Nom</a></th>
        <th><a href="admin_afficher_contacts.php?OrderBy=mail">Mail</a></th>
        <th><a href="admin_afficher_contacts.php?OrderBy=message">Message</a></th>
        <th><a href="admin_afficher_contacts.php?OrderBy=date">Date</a></th>
        <th><a href="admin_afficher_contacts.php?OrderBy=statut">Statut</a></th>
    </thead>

<?php
        while($ligne=$resultat->fetch()){
            $i++;
            $message = substr($ligne['message'], 0, 50);
            if($ligne['statut']){
                $statut = "Traité";
                $class = "green";
            }
            else {
                $statut = "Non Traité";
                $class = "orange";
            }
            echo "<tr class='$class'>
            <td><a href='admin_afficher_message.php?numContact=$ligne[numContact]'>$ligne[numContact]</a></td>
            <td>$ligne[prenom]</td>
            <td>$ligne[nom]</td>
            <td>$ligne[mail]</td>
            <td>$message</td>
            <td>$ligne[date]</td>
            <td>$statut</td>
            </tr>";
        }
        echo "</table>";
        echo "Nombre de messages : $i";
?>

</body>
</html>