<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/Contact.css">
    <title>Authentification</title>
</head>
<body>
<?php
session_start();
if(isset($_POST['login'])){
    include('connexion.php');
    $login = sha1($_POST['login']);
    $password = sha1($_POST['password']);

    // Connexion pour les utilisateurs
    $requete = 'SELECT * FROM msm_login;';
    $resultat = $dbh->query($requete);

    while($ligne=$resultat->fetch()){
        if(($login == $ligne['login']) && ($password == $ligne['password'])){
            $resultat->closeCursor();
            $_SESSION['login'] = $login;
            header('Location: admin_afficher_contacts.php');
            exit;
        }
    }
    header('Location: admin_connexion.html');
    exit;
}
else {
    header('Location: admin_connexion.html');
    exit;
}
?>
</body>