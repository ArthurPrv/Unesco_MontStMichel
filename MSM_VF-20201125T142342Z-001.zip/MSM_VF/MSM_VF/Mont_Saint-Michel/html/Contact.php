<?php
if (isset($_GET['language']) && ($_GET['language']=="en" || $_GET['language']=="fr")) {
    $language = $_GET['language'];
    $_SESSION['language']=$language;
}
elseif(isset($_SESSION['language']) && ($_SESSION['language']=="en" || $_SESSION['language']=="fr")) {
    $language=$_SESSION['language'];
}
else {
    $language = "fr";
}
?>


<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="../css/Contact.css">
        <link rel="icon" type="image/png" href="../img/logoMSMPetit.png" sizes="16x16">
        <title>Contact</title>
    </head>
    <?php if($language=="en"){ ?>
        <body>
        <div class="head">
            <h3>Contact Us</h3>
            <a href=<?php echo ($_SERVER['PHP_SELF'].(($language=="en") ? "?language=fr" : "?language=en")); ?> ><img <?php echo(($language=="en") ? "src=../img/drapeaufr.png" : "src=../img/ang.png"); ?> ></a>

        </div>
        <form action="Contact2.php" method="post">
            <fieldset>
                <legend>Contact us</legend>
                <label for="lastName">Last name</label>
                <input type="text" name="nom" id="lastName" autocomplete="on" placeholder="Last name" pattern="[a-zA-ZÀ-ÿ]+" autofocus required>
                <label for="firstName">First Name</label>
                <input type="text" name="prenom" id="firstName" autocomplete="on" placeholder="First name" pattern="[a-zA-ZÀ-ÿ]+" required>
                <label for="email">Email</label>
                <input type="email" name="mail" id="email" autocomplete="on" placeholder="votre@email.fr" required>
                <label for="message">Your message</label>
                <textarea name="message" id="message" placeholder="Write your message here, (3000 characters maximum)" required>Hello, I'd like to point out that...</textarea>
                <input type="reset" value="Delete">
                <input type="submit" value="Send">
            </fieldset>
        </form>
        <h2>Home Page <a href="index.php?language=en">here</a></h2>
        </body>
    <?php }else{?>
    <body>
        <div class="head">
        <h3>Nous Contacter</h3>
            <a href=<?php echo ($_SERVER['PHP_SELF'].(($language=="en") ? "?language=fr" : "?language=en")); ?> ><img <?php echo(($language=="en") ? "src=../img/drapeaufr.png" : "src=../img/ang.png"); ?> ></a>

        </div>
        <form action="Contact2.php" method="post">
            <fieldset>
                <legend>Nous Contacter</legend>
                <label for="lastName">Nom</label>
                <input type="text" name="nom" id="lastName" autocomplete="on" placeholder="nom" pattern="[a-zA-ZÀ-ÿ]+" autofocus required>
                <label for="firstName">Prénom</label>
                <input type="text" name="prenom" id="firstName" autocomplete="on" placeholder="prénom" pattern="[a-zA-ZÀ-ÿ]+" required>
                <label for="email">Email</label>
                <input type="email" name="mail" id="email" autocomplete="on" placeholder="votre@email.fr" required>
                <label for="message">Votre Message</label>
                <textarea name="message" id="message" placeholder="Écrivez votre message ici (3000 caractères maximum)" required>Bonjour, j'aimerais vous indiquer que ...</textarea>
                <input type="reset" value="Effacer">
                <input type="submit" value="Envoyer">
            </fieldset>
        </form>
        <h2>Accueil <a href=<?php echo "index.php?language=".$language; ?>>ici</a></h2>
    </body>

<?php } ?>
</html>
