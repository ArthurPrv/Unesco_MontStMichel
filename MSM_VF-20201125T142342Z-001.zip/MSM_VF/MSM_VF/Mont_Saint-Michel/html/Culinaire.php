<?php
if (isset($_GET['language']) && ($_GET['language']=="en" || $_GET['language']=="fr")) {
    $language = $_GET['language'];
    $_SESSION['language']=$language;
}
elseif(isset($_SESSION['language']) && ($_SESSION['language']=="en" || $_SESSION['language']=="fr")) {
    $language=$_SESSION['language'];
}
else {
    $language = "fr";
}
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title><?php echo(($language=="en") ? "Culinary Art"  : "Art Culinaire");?></title>
        <link rel="stylesheet" type="text/css" href="../css/Culinaire.css">
        <link rel="icon" type="image/png" href="../img/logoMSMPetit.png" sizes="16x16">
    </head>

    <?php include('header.php'); ?>
    <?php if($language=="en"){ ?>
        <body>


            <div class="begin">
                <h1>Culinary Art</h1>
            </div>
        </header>

        <div class="sommaire">
            <span class="sommaire2"><a href=<?php echo ("../html/index.php?language=".$language) ?>>Home &nbsp </a> >
            <a href=<?php echo ("../html/Culture.php?language=".$language) ?>>&nbsp Culture &nbsp</a>><a href= <?php echo ("../html/Culinaire.php?language=".$language) ?>>Culinary art</a></span>
        </div>

        <section class="rubrique1">
            <div class="grandTitre">
                <div class="titre">
                    <h1>History of Culinary Art</h1>
                </div>
            </div>
            <div class="texteImage">
                <img src="../img/restaurant.jpg">
                <p>
                    The Mother Poulard of her real name, Annette Poulard, is a symbol of the French culinary tradition thanks to her cuisine.
                    The Mont Saint-Michel, located between Brittany and Normandy, is where she lives and where she has forged her image thanks to her soufflé omelette. It is thus more than 130 since 1888 that Mother Poulard's inn has been attracting admirers.

                </p>
                <br>
                <br>

                <h1>Mother Poulard, who was she?</h1>

                <p>Born in France, more precisely in Nevers, Mère Poulard used to work in Paris for the architect Edouard Corroyer as a maid and cook. In 1872 she was appointed by the French government to renovate the Abbey of Mont Saint-Michel and that this rocky islet no longer remains the prison it was between 1793 and 1863. It was then that on Mount Annette met Victor Poulard and together they acquired the "Hotel Saint-Michel Teste d'Or" which was later renamed "Lyon d'Or". Later they demolished it to rebuild the famous institution "A l'omelette renommée de la Mère Poulard".
                </p>
                <br>
                <br>

                <h1>The institution that is L'auberge de la Mère Poulard</h1>

                <p>The Mère Poulard Inn was founded in 1888. It was the first inn on the mountain to offer individual tables, which was comical at the time. It should also be noted that the name was given at the time to the best cooks in France.
                    In the same way as a destination for celebrities, in the 20th century it was the place where one had to expose oneself. At the time, Mother Poulard used to ask customers to leave a trace of their travels. That's how we find in this establishment dedications of Edouard VII, Coco Chanel, Picasso, Foujita.
                    <br>
                </p>
                <br>
                <br>

                <h1>Mother Poulard and her soufflé omelette</h1>

                <p>Mother Poulard's omelette
                    It is a secret recipe that comes from myth, Anette Poulard being an excellent cook prepared this omelette is said to be soufflé and sometimes sprinkled with fresh cream, the eggs are beaten to a special rhythm in a copper basin before being cooked over a wood fire in a copper pan.this omelette was designed for hungry pilgrims arriving at Mont Saint-Michel, as it was simple and quick to prepare at any time of the day.

                    <br>
                    Anecdotes:
                    It takes a month of training for an omelet maker to know how to make the Mère Poulard omelet properly, "a month and a half to get rid of the pain in the wrist" adds anecdotally Alain Grespier, the chef of the inn.
                    When the omelet makers beat the eggs, there can be up to six of them, so they all have to whisk in the same way to be in harmony.
                    Today they use about 300,000 eggs a year, these are outdoor eggs from the Delaunay farm, which has been a supplier since 1888
                </p>
                <br>
                <br>

                <h1>Her lucky biscuits</h1>
                <p>All her life Annette Poulard also made buttered biscuits. She distributed them to the visitor, but did not sell them. Thanks to the writings of Mother Poulard, and the palace of Éric Vannier, several dry cookies appeared on the market. Among the best known were shortbread and pure butter palets.
                </p>

            </div>
        </section>
        <hr>
        <section class="rubrique1">
            <h1 class="titre">Hotel-Restaurant La Mère Poulard</h1>

            <div class="description">
                <a href="encours.php">
                    <img src="../img/merepoulard.jpg">
                    <div>
                        <p>TEL : 02 33 89 68 68 / FAX : 02 33 89 68 69<br>
                            Grande Rue BP 18
                            50170 LE MONT SAINT MICHEL<br><br>
                            In a unique setting in the world, nestled in the heart of the medieval city of Mont Saint-Michel, the inn of Mère Poulard offers you the charm and comfort of its hotel, the tradition and quality of its restaurant, the warmth and friendliness of its piano bar: an unforgettable moment in this magical place steeped in history.</p>
                    </div>
                </a>
            </div>
        </section>

        <footer>
            <?php include ('footer.php')?>
        </footer>

        <div id="scroll_to_top"  class="fleche">
            <a href="#top"><img src="../img/top.png" alt="Retourner en haut" /></a>
        </div>
        </body>
    <?php }else{?>
        <body>



            <div class="begin">
                <h1><?php echo(($language=="en") ? "Culinary Art"  : "Art Culinaire");?></h1>
            </div>
        </header>

        <div class="sommaire"> 
            <span class="sommaire2"><<a href=<?php echo ("../html/index.php?language=".$language) ?>>Accueil &nbsp </a> >
            <a href=<?php echo ("../html/Culture.php?language=".$language) ?>>&nbsp Culture &nbsp</a>><a href= <?php echo ("../html/Culinaire.php?language=".$language) ?>>Art Culinaire</a></span>
        </div>

        <section class="rubrique1">
            <div class="grandTitre">
                <div class="titre">
                    <h1>Histoire de l'art culinaire</h1>
                </div>
            </div>
            <div class="texteImage">
                <img src="../img/restaurant.jpg">
                <p>
                    La Mère Poulard de son vrai nom Annette Poulard est à elle seule grâce à sa cuisine un symbole de la tradition culinaire française.
                    Le mont Saint-Michel situé entre la Bretagne et la Normandie, est là où réside cette personne et où elle a forgée son image grâce à son omelette soufflée. Cela fait donc plus de 130 depuis 1888 que l’auberge de la mère Poulard ne cesse d’attirer les admirateurs.
                </p>
                <br>
                <br>

                <h1>La Mère Poulard, Qui était elle?</h1>

                <p>Née en France, plus précisément à Nevers, la Mère Poulard travaillait autrefois à Paris pour l’architecte Edouard Corroyer en tant que servante et cuisinière. En 1872, elle fut nommée par le gouvernement français pour rénover l’abbaye du mont Saint-Michel et que cet îlot rocheux ne reste plus la prison qu’il fut entre 1793 et 1863. C’est alors que sur le mont Annette fit la rencontre de Victor Poulard et qu’ensemble ils firent l'acquisition de “L’hôtel Saint-Michel Teste d’Or” qui par la suite fut renommée “Lyon d’Or”. Par la suite, ils le démolissent pour reconstruire la célèbre institution “A l’omelette renommée de la Mère Poulard”</p>
                <br>
                <br>

                <h1>L’institution qu’est L’auberge de la Mère Poulard</h1>

                <p>L’auberge de la Mère Poulard voit le jour en 1888. Ce fut la première auberge du mont à proposer des tables individuelle ce qui était cocasse à l’époque. Il faut également noter que l'appellation était à l’époque donnée aux meilleures cuisinières de France.
                Au même titre qu’une destination de célébrités, au XXe siècle, c’est l’endroit où l’on devait s'exposer. La mère Poulard avait alors à l’époque pour habitude de demander aux clients de laisser une trace de leur voyage. C’est comme ça qu’on retrouve dans cet établissement des dédicaces de Edouard VII,Coco Chanel,Picasso,Foujita. <br>
                </p>
                <br>
                <br>

                <h1>La Mère Poulard et son omelette soufflée</h1>

                <p>L'omelette de la Mère Poulard. 
                C’est une recette secrète qui relève du mythe, Anette Poulard étant une excellente cuisinière préparait cette omelette est dites soufflée et parfois parsemé de crème fraîche, les oeufs sont battus en neige dans une bassine de cuivre selon un rythme spécial, tout cela avant d’être cuite au feu de bois dans une poêle en cuivre.Cette omelette a été conçue pour les pèlerins affamés arrivant au Mont Saint-Michel, comme ce dernier était simple et rapide à préparer à toute heure.
                    
                <br>
                Anecdotes:
                    Il faut un mois de formation pour qu’un omelettier sache correctement réaliser l’omelette de la Mère Poulard, « un mois et demi pour ne plus avoir mal au poignet » ajoute de façon anecdotique Alain Grespier, le chef de l’auberge.
                    Quand les omelettiers battent les œufs, ils peuvent être jusqu’à six, ils doivent donc tous fouetter de la même façon pour être en harmonie.
                    Aujourd’hui ils utilisent environ 300 000 œufs par an, ce sont des œufs de plein air qui proviennent de la ferme Delaunay, fournisseur depuis 1888.
                </p>
                <br>
                <br>

                <h1>Ses biscuits porte-bonheur</h1>
                <p>Toute sa vie Annette Poulard a également fait des biscuits beurrés. Elle en distribuait au visiteur, mais ne les vendait pas. Grâce aux écrits de la Mère Poulard, et au palais d’Éric Vannier, plusieurs biscuits secs ont fait leur apparition dans le commerce. Parmi les plus connus les sablés et les palets pur beurre.
                </p>
            
            </div>
        </section>
        <hr>
        <section class="rubrique1">
            <h1 class="titre">Hôtel-Restaurant La Mère Poulard</h1>
        
            <div class="description">
                <a href="encours.php">
                <img src="../img/merepoulard.jpg">
                <div>
                    <p>TEL : 02 33 89 68 68 / FAX : 02 33 89 68 69<br>
                        Grande Rue BP 18
                        50170 LE MONT SAINT MICHEL<br><br>
                    Dans un cadre unique au monde, blottie au coeur de la cité médiévale du Mont Saint-Michel, l'auberge de la Mère Poulard vous offre le charme et le confort de son hôtel, la tradition et la qualité de son restaurant, la chaleur et la convivialité de son piano-bar : un moment inoubliable dans ce lieu magique chargé d'histoire.</p>
                </div>
                </a>
            </div>
        </section>

        <footer>
            <?php include ('footer.php') ?>
        </footer>

        <div id="scroll_to_top"  class="fleche"> 
            <a href="#top"><img src="../img/top.png" alt="Retourner en haut" /></a> 
        </div>
    </body>
    <?php } ?>
</html>
