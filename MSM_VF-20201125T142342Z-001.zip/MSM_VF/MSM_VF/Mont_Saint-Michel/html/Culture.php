<?php
if (isset($_GET['language']) && ($_GET['language']=="en" || $_GET['language']=="fr")) {
    $language = $_GET['language'];
    $_SESSION['language']=$language;
}
elseif(isset($_SESSION['language']) && ($_SESSION['language']=="en" || $_SESSION['language']=="fr")) {
    $language=$_SESSION['language'];
}
else {
    $language = "fr";
}
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="../css/Culture.css">
        <link rel="icon" type="image/png" href="../img/logoMSMPetit.png" sizes="16x16">
        <script type="text/javascript" src="../js/Accueil_2.0.js"></script>
        <title>Culture - Mont-St-Michel</title>
    </head>
    
    <body>


        <header>
            <?php include ('header.php')?>


            <div class="begin">
                <h1>Culture</h1>
            </div>
        </header>

        <?php if($language=="en"){ ?>

        <div class="sommaire">
            <span class="sommaire2"><a href=<?php echo ("../html/index.php?language=".$language) ?>>Home</a> > Culture</span>
        </div>

        <div class="slideshow-container">
            <h3 class="cultureh3">Come and Discover:</h3>
            <hr width="5%">
            <!-- Full-width images with number and caption text -->
            <div class="mySlides fade">
                <div class="numbertext">1 / 3</div>
                <section id="onglets">
                    <a  href=<?php echo ("../html/Architecture.php?language=".$language) ?>><div class="architecture container">
                            <img src="../img/ArchitectureAccueil.png">
                            <div class="rubrique">
                                <h3>Architecture</h3>
                                <hr width="5%">
                                <p> Explore every nook and cranny of Mont-Saint-Michel. How was it founded, with what materials? Here you'll get your answer. </p>
                            </div>
                        </div></a>
                </section>
            </div>

            <div class="mySlides fade">
                <div class="numbertext">2 / 3</div>
                <section id="onglets">
                    <a  href=<?php echo ("../html/Religion.php?language=".$language) ?>><div class="architecture container">
                            <img src="../img/ReligionAccueil.jpg">
                            <div class="rubrique">
                                <h3>Religion</h3>
                                <hr width="5%">
                                <p> Before thinking of Mont-Saint-Michel as a tourist destination, we must not forget that it is above all a place of pilgrimage. Discover here the whole Mont-Saint-Michel's religious history. </p>
                            </div>
                        </div></a>
                </section>
            </div>

            <div class="mySlides fade">
                <div class="numbertext">3 / 3</div>
                <section id="onglets">
                    <a  href=<?php echo ("../html/Culinaire.php?language=".$language) ?>><div class="architecture container">
                            <img src="../img/restaurant.jpg">
                            <div class="rubrique">
                                <h3>Culinary art</h3>
                                <hr width="5%">
                                <p>In this category, you can find the specialties of Mont-Saint-Michel. </p>
                            </div>
                        </div></a>
                </section>
            </div>


            <!-- Next and previous buttons -->
            <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
            <a class="next" onclick="plusSlides(1)">&#10095;</a>

            <div style="text-align:center">
                <span class="dot" onclick="currentSlide(1)"></span>
                <span class="dot" onclick="currentSlide(2)"></span>
                <span class="dot" onclick="currentSlide(3)"></span>
            </div>
        </div>
        <?php }else{?>



        <div class="sommaire">
            <span class="sommaire2"><a href=<?php echo ("../html/index.php?language=".$language) ?>>Accueil</a> > Culture</span>
        </div>

        <div class="slideshow-container">
            <h3 class="cultureh3">Venez Découvrir:</h3>
            <hr width="5%">
            <!-- Full-width images with number and caption text -->
            <div class="mySlides fade">
              <div class="numbertext">1 / 3</div>
              <section id="onglets">
                <a  href=<?php echo ("../html/Architecture.php?language=".$language) ?>><div class="architecture container">
                    <img src="../img/ArchitectureAccueil.png">
                    <div class="rubrique">
                        <h3>Architecture</h3>
                        <hr width="5%">
                        <p> Explorez le Mont-Saint-Michel dans ses moindres recoins. Comment a-t-il été fondé, avec quelles matériaux ? Ici vous aurez votre réponse. </p>
                    </div>
                </div></>
               </section>
            </div>
          
            <div class="mySlides fade">
              <div class="numbertext">2 / 3</div>
              <section id="onglets">
                  <a  href=<?php echo ("../html/Religion.php?language=".$language) ?>><div class="architecture container">
                    <img src="../img/ReligionAccueil.jpg">
                    <div class="rubrique">
                        <h3>Religion</h3>
                        <hr width="5%">
                        <p> Avant de penser au Mont-Saint-Michel en tant que lieu touristique, il ne faut pas oublier que c'est avant tout un lieu de pelerinage. Découvrez ici toute l'histoire religieuse du Mont-Saint-Michel-au-péril-de-la-Mer </p>
                    </div>
                </div></a>
              </section>
            </div>
          
            <div class="mySlides fade">
              <div class="numbertext">3 / 3</div>
              <section id="onglets">
                  <a  href=<?php echo ("../html/Culinaire.php?language=".$language) ?>><div class="architecture container">
                    <img src="../img/restaurant.jpg">
                    <div class="rubrique">
                        <h3>Culinaire</h3>
                        <hr width="5%">
                        <p> Dans cette catégorie, vous pourrez retrouver les spécialités du Mont-Saint-Michel.</p>
                    </div>
                </div></a>
              </section>
            </div>
        
          
            <!-- Next and previous buttons -->
            <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
            <a class="next" onclick="plusSlides(1)">&#10095;</a>

            <div style="text-align:center">
                <span class="dot" onclick="currentSlide(1)"></span>
                <span class="dot" onclick="currentSlide(2)"></span>
                <span class="dot" onclick="currentSlide(3)"></span>
              </div>
        </div>

        <?php } ?>



        <div id="scroll_to_top" class="fleche"> 
            <a href="#top"><img src="../img/top.png" alt="Retourner en haut" /></a> 
        </div>
        
        <script>
            var slideIndex = 1;
            showSlides(slideIndex);
        </script>

    </body>
        <?php include ('footer.php')?>
</html>