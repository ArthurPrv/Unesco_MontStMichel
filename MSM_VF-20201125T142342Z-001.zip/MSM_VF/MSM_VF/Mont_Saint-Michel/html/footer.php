<?php
if (isset($_GET['language']) && ($_GET['language']=="en" || $_GET['language']=="fr")) {
    $language = $_GET['language'];
    $_SESSION['language']=$language;
}
elseif(isset($_SESSION['language']) && ($_SESSION['language']=="en" || $_SESSION['language']=="fr")) {
    $language=$_SESSION['language'];
}
else {
    $language = "fr";
}
?>

            <div class="footer">
                <a target="_blank" href="https://www.univ-gustave-eiffel.fr/"><img src="../img/upem.jpg" class="upem" sizes="120x93"></a>
                <a target="_blank" href="https://www.enseignementsup-recherche.gouv.fr/pid24578/investissements-d-avenir.html" ><img src="../img/Investissement_davenir.png" class="investissement"></a>
                <a target="_blank" href="https://anr.fr/"><img src="../img/logoANR_blanc.png" class="anr"></a>

                <?php if($language=="en"){ ?>
                    <nav>
                        <a class="an" href= <?php echo ("../html/MentionLegales.php?language=".$language) ?>>Impressum</a>
                        <a class="an" href=<?php echo ("../html/Qsn.php?language=".$language) ?>>About us</a>
                        <a class="an" href=<?php echo ("Contact2.php?language=".$language) ?>>Contact us</a>
                    </nav>

                <?php }else{?>

                    <nav>
                        <a class="fr" href= <?php echo ("../html/MentionLegales.php?language=".$language) ?>>Mentions Légales</a>
                        <a class="fr" href=<?php echo ("../html/Qsn.php?language=".$language) ?>>Qui sommes-nous</a>
                        <a class="fr" href=<?php echo ("Contact2.php?language=".$language) ?>>Nous contacter</a>
                    </nav>
                <?php } ?>
                <img src="../img/mcn.PNG" class="mcn" sizes="93x60">
                <a target="_blank" href="https://fr.unesco.org/">  <img src="../img/unesco.PNG" class="unesco"></a>
                <a target="_blank" href="https://fr.unesco.org/forum">  <img src="../img/forumunesco_blanc.png" class="forum"></a>
            
            </div>    
