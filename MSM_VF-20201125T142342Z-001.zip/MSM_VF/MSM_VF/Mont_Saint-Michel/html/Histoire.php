<?php
if (isset($_GET['language']) && ($_GET['language']=="en" || $_GET['language']=="fr")) {
    $language = $_GET['language'];
    $_SESSION['language']=$language;
}
elseif(isset($_SESSION['language']) && ($_SESSION['language']=="en" || $_SESSION['language']=="fr")) {
    $language=$_SESSION['language'];
}
else {
    $language = "fr";
}
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="../css/Histoire.css">
        <link rel="icon" type="image/png" href="../img/logoMSMPetit.png" sizes="16x16">
        <script type="text/javascript" src="../js/Histoire.js"></script>
        <title><?php echo(($language=="en") ? "History"  : "Histoire"); ?> - Mont Saint Michel</title>
    </head>
    <body>

        <header>
            <?php include ('header.php')?>


            <div class="begin">
                <h1><?php echo(($language=="en") ? "History"  : "Histoire"); ?></h1>
            </div>

        </header>

        <?php if($language=="en"){ ?>
            <div class="sommaire3">
            <span class="sommaire2"><a href=<?php echo ("../html/index.php?language=".$language) ?>>Home &nbsp </a> >
            <a href=<?php echo ("../html/Histoire.php?language=".$language) ?>>&nbsp History</a></span>
            </div>

            <section class="rubrique">
                <div class="sommaire">
                    <h2>Contents</h2>
                    <a  href="#chap1"><h5>1. The Mount Tomb</h5></a>
                    <a href="#chap2"><h5>2. A complicated beginning</h5></a>
                    <a href="#chap3"><h5>3. A new beginning</h5></a>
                    <a href="#chap4"><h5>4. A period of chaos</h5></a>
                    <a href="#chap5"><h5>5. The Mount, a prison</h5></a>
                    <a href="#chap6"><h5>6. Between restoration and return to religion</h5></a>
                    <a href="#chap7"><h5>7. The Saint-Michel project</h5></a>
                </div>


                <div class="texte">
                    <h2>The history of the Mount</h2>
                    <h3  id="chap1">1. The Mount Tomb</h3>
                    <p>
                        There is no scientific proof of this, but legend has it that “Mont-Tombe” has its origins in antiquity where Druids held a cult.


                        The most probable hypothesis is that the name “Mont-Tombe” comes from the fact that it emerges from the sand like a tomb.
                        In any case, Mount Tombs has undergone many changes during its history. Originally, in the 4th century, hermits (probably Celtic monks) occupied the mount.
                        From the 5th century, the cult of Saint Michael in the West developed and, in 708, the bishop Saint Aubert d'Avranches decided to build an oratory dedicated to the archangel Michael.
                        He roughly built a hotel that was supposed to house the relics of Saint Michael that he had recovered from the sanctuary of Saint Michael at “Mont-Gargan” in Italy. It was in 709 that a tidal wave would have made “Mont-Tombe” the island it is today at high tide.
                        In 709, more precisely on October 16, the bishop of Avranches sacralized the church of the mount and installed 12 canons. This was the creation of Mont-Saint-Michel.
                    </p>


                       <details  >
                            <summary>More informations</summary>
<p>
                        <img class="ilu" src="../img/histoire_1.jpg">
                        <h3  id="chap2">2. A complicated beginning</h3>
                        <p>
                            For a century, the canons followed one another and continued the task entrusted to them. However, the Vikings attacked one after the other and in 847 they plundered the abbey church completely.


                    After these sad events, the attacks stopped, but it is impossible to say whether this was the result of an alliance between the Count of Rennes and the Vikings or whether it was the development of the mountain's defences.
                            The Mount is the property of Normandy, but already at that time, the Bretons and the Normans were fighting over the coastline of the bay of the Mount. With the growing number of pilgrims and the income they generated, the canons gradually deviated from their mission.
                            This situation damaged the image of the abbey to such an extent that, around 965, with the agreement of Pope John XIII and King Lothaire (King of the Franks from 954 to 986), the canons were replaced by Benedictine monks (who followed the rules of Saint Benedict).
                            The canons had the choice between submitting to the rules of Saint Benedict or leaving the Mount.
                            Only 1 canon decided to stay. This year 965 (or 966 depending on the version) is the year that was chosen as the year of the creation of Mont-Saint-Michel.            </p>

                        <h3  id="chap3">3.  A new beginning</h3>
                        <p>
                            Since then, the Mount has continued to grow, notably with the construction of the Notre-Dame-Sous-Terre church, which to this day remains one of the oldest parts of the Mount open to visitors.The stones used for the progressive construction of the mount are mainly extracted from the Chausey Islands and transported by boat to the mount.
                            Around 1015, the bay was definitely taken over by the Normans from the Bretons, but this did not prevent the Dukes of Brittany, Conan le Tort and Geoffroy 1st, from being buried as 'Benefactors of Mont-Saint-Michel'. The mont saint michel also has at that time a very big political value because it makes it possible to show that Normandy defends the Christian religion on its territory.
                            Very quickly, the abbey becomes again a major place of pilgrimage of the Christian West but it also takes value thanks to all the books translated by the monks, by recalling that at that time, a book is a valuable object. Mont-Saint-Michel is even nicknamed by some 'City of Books'. Many important people visit the mountain, including the kings of France and England.
                            The abbey is at its peak at that time.
                        </p>


                        <img class="ilu2" src="../img/histoire_2.jpg">
                        <h3  id="chap4">4. A period of chaos</h3>

                        <p>
                            In 1204, the Breton troops are fighting against the Mount.

                            It was a massacre and they killed all the Montois, making no distinction between men and women, adults and children, clergymen and laymen.
                            After killing everyone, they set fire to the town. The fire was so violent that almost all the buildings were reduced to ashes. Some walls and vaults were not destroyed. The King of France, wanting to restore the appearance of the Mount to the level of the pilgrims' expectations, launched very important repairs.
                            The reconstruction was completed in 1228. The abbey then tried to revive and revive its economy but in 1356, in the middle of the Hundred Years' War, the English took Tombelaine, a large rock in the Bay of the Mount, from where they could begin the siege of the abbey. Quickly, the Montois defend themselves and push back the English troops for several years. The Michelois reinforce their defences with the construction of ramparts but,
                            in 1423, the English establish a blockade by building 2 bastilles, one of which is on the rock of Tombelaine. Despite numerous attempts, the Montois were unable to defeat the English and the blockade became increasingly restrictive. It becomes more and more difficult for the Montois to get supplies without losing troops. In 1433, a new fire destroyed part of the town and the English took advantage of this and attacked on June 17, 1434.
                            This attack was a total failure for the English who were repulsed by the Montois and were forced to lift the blockade.
                            However, the English would remain in the fortresses of Tombelaine until the liberation of Normandy in 1450.</p>

                        <h3  id="chap5">5. The Mount, a prison</h3>
                        <p>
                            After these years of chaos, the prestige of the abbey continues to decline, to the point that the place of pilgrimage is beginning to be transformed into a prison. The Mont will become a state prison under the reign of Louis XI. The monks no longer respected morals (some had wives and children) which led the various kings of France to use the Mont only as a prison and it even took the name of "bastille of the seas".
                            However, this title of state prison has probably made it possible to visit Mont-Saint-Michel today. Indeed, in 1789, most of the religious buildings fell into ruins and were razed to the ground because of the French Revolution. The last monks left the abbey in 1791 and the only vocation of the Mont is now penitentiary. In 1793, more than 300 priests were locked up there. Up to 700 people were held prisoner at the same time and the living conditions were denounced by many authors and politicians.
                            The prisoners worked in workshops set up in the abbey. In 1863, Napoleon III took the decision to close this prison. In total, more than 14,000 prisoners will have served their sentences between the ramparts of Mont Libre, as it is called during this period
                        </p>
                        <h3  id="chap6">6.  Between restoration and return to religion</h3>
                        <img class="ilu3" src="../img/histoire_3.png">
                        <p>
                            Major renovation work began as early as 1863 and in 1877, a large gathering attracted more than 25,000 pilgrims to the Mount. Between 1878 and 1880, a road embankment was built to provide access to the Mount from the mainland. The renovation work lasted until the beginning of the 20th century. In 1922, worship was restored in the abbey. In 1966, to celebrate the millennium of the abbey, many communities of Benedictine monks send monks to spend a year on the mount.
                            Some will choose to stay after this year and by their presence, they help to restore the religious character that was originally attributed to this place. An explosion in the number of tourists took place in the 1960s with the development of the automobile, paid holidays and the economic growth of the country. However, the monks deserted the mountain little by little after 1979. Since 2001, they have been replaced by brothers and sisters from the monastic fraternities of Jerusalem. They are present on the Mount all year round.
                        </p>

                        <h3  id="chap7">7. The Saint-Michel project</h3>
                        <p>
                            This project which, in 1990, was called "désensablement du Mont" is now called "restoration of the maritime character of Mont-Saint-Michel". The main objective of this project is to allow the Mount to maintain its insularity 20 days a year during high tides. In addition, the objective is to gradually eliminate the schorres (or pre-salted schorres) that have formed around Mont Saint Michel due to human activity.
                        </p>


                </p>
                </details>
                </div>


            </section>

        <?php }else{ ?>
        <div class="sommaire3">
            <span class="sommaire2"><a href=<?php echo ("../html/index.php?language=".$language) ?>>Accueil &nbsp </a> >
            <a href=<?php echo ("../html/Histoire.php?language=".$language) ?>>&nbsp <?php echo(($language=="en") ? "History"  : "Histoire"); ?></a></span>
        </div>

        <section class="rubrique">
            <div class="sommaire">
                <h2>Sommaire</h2>
                <a href="#chap1"><h5>1. Le Mont Tombe</h5></a>
                <a href="#chap2"><h5>2.Des débuts compliqués</h5></a>
                <a href="#chap3"><h5>3. Un renouveau</h5></a>
                <a href="#chap4"><h5>4. Une période de chaos</h5></a>
                <a href="#chap5"><h5>5. Le Mont, une prison</h5></a>
                <a href="#chap6"><h5>6. Entre restauration et retour vers la religion</h5></a>
                <a href="#chap7"><h5>7. Le projet Saint-Michel</h5></a>
            </div>


            <div class="texte">
                <h2>L'histoire du Mont</h2>
                <h3  id="chap1">1. Le Mont tombe</h3>
                <p>
                    Il n’y a pas de preuves scientifiques de cela, mais la légende raconte que le Mont-Tombe tient ses origines de l’antiquité ou des druides y tenaient un culte. L'hypothèse la plus probable dit que le nom ‘Mont-Tombe’ vient du fait que ce dernier émerge du sable à la manière d’un tombeau.
                    Quoiqu'il en soit, ce Mont-Tombe a connu de nombreuses modifications durant son histoire.
                    À l’origine, au IVème siècle, des ermites(probablement des moines celtes) occupent le mont. Dès le Vème siècle, le culte de Saint Michel en Occident se développe et, en 708, l'évêque Saint Aubert d’Avranches décide de construire un oratoire dédié à l’archange Michel. Il construit grossièrement un hotel censé accueillir les reliques de Saint Michel qu’il a récupéré du sanctuaire de Saint-Michel au Mont-Gargan en Italie.
                    C’est en 709 qu’un raz-de-marée aurait fait du Mont-Tombe l'île qu’elle est aujourd'hui à marée haute.C’est la création du Mont-Saint-Michel.
                </p>



                    <details  >
                        <summary>Plus d'informations</summary>
                        <p>

                <img class="ilu" src="../img/histoire_1.jpg">
                <h3  id="chap2">2. Des débuts compliqués</h3>
                <p>
                    Durant 1 siècle, les chanoines se suivent et continuent la tâche qui leur a été confiée. Cependant, les attaques des Vikings s'enchaînent et, en 847, ils pillent intégralement l'église abbatiale.
                    Après ces tristes événements, les attaques stoppent mais il est impossible de dire si cela est le résultat d’une alliance entre le comte de Rennes et les Vikings ou s’il s’agit du développement des défenses du mont.
                    Le Mont est la propriété de la Normandie mais, déjà à cette époque, les Bretons et les Normands se disputent le littoral de la baie du Mont.


                    Avec le nombre croissant de pèlerins et de revenus qu’ils génèrent, les chanoines s'écartent peu à peu de leur mission. Cette situation a dégradé l’image de l’abbaye a tel point que, vers 965, avec l’accord du Pape Jean XIII et du roi Lothaire (Roi des Francs de 954 à 986),
                    les chanoines sont remplacés par des moines Bénédictins (qui suivent les règles de Saint Benoît). Les chanoines ont eu le choix entre se soumettre aux règles de Saint Benoît ou bien quitter le Mont. Seul 1 chanoine a décidé de rester. Cette année 965 (ou 966 selon les versions) est celle qui a été retenue comme celle de la création du Mont-Saint-Michel.
                </p>

                <h3  id="chap3">3. Un renouveau</h3>
                <p>
                    Dès lors, le Mont ne cesse de s’agrandir, notamment avec la construction de l'église Notre-Dame-Sous-Terre qui reste à ce jour l’une des plus vieilles partie du mont ouverte à la visite. Les pierres servant à la construction progressive du mont sont principalement extraites des îles Chausey et acheminées par barque sur le mont.
                    Vers 1015, la baie est définitivement reprise par les Normands sur les Bretons, mais cela n'empêche pas les ducs de Bretagne Conan le Tort et Geoffroy 1er de se faire ensevelir en tant que ‘Bienfaiteurs du Mont-Saint-Michel’. Le mont saint michel a également à cette époque une très grosse valeur politique car il permet de montrer
                    que la normandie défend la religion Chrétienne sur son territoire. Très vite, l’abbaye redevient un lieu de pèlerinage majeur de l’Occident Chrétien mais elle prend aussi de la valeur grâce à tous les livres traduits par les moines, en rappelant qu'à cette époque, un livre est un objet de valeur. Le Mont-Saint-Michel est même surnommé par certains ‘Cité des Livres’.
                    De nombreuses personnes importantes visitent le mont notamment les rois de France et d’Angleterre. L’abbaye est à son apogée à cette époque.

                </p>
                <img class="ilu2" src="../img/histoire_2.jpg">
                <h3  id="chap4">4. A period of chaos</h3>

                <p>
                    En 1204, les troupes bretonnes s’acharnent contre le Mont. Ce fut un massacre et ils tuent tous les Montois, sans faire de distinctions entre hommes et femmes, adultes et enfants, homme d'Église et laïcs.
                    Après avoir tué tout le monde, ils mirent le feu à la ville. Le feu fut si violent que presque tous les bâtiments furent réduits en cendres. Quelques murs et voûtes ne furent pas détruits.

                    Le roi de France, voulant redonner au Mont une apparence a la hauteur des attentes de pèlerins, lança des réparations très importantes. La reconstruction fut achevée en 1228. L’abbaye tenta ensuite de relancer et de relancer l'économie de cette dernière mais en 1356, alors que nous sommes en pleine guerre de Cent ans, les Anglais prennent Tombelaine, un gros rocher dans la Baie du Mont, d'où ils peuvent commencer le siège de l’abbaye. Rapidement, les Montois se défendent et repoussent les troupes anglaises pour plusieurs années.

                    Les Michelois renforcent leurs défenses avec la construction de remparts mais, en 1423, les Anglais établissent un blocus en construisant 2 bastilles dont une sur le rocher de Tombelaine. Malgré de nombreuses tentatives, les Montois ne parviennent pas à battre les Anglais et le blocus est de plus en plus restrictif. Il devient de plus en plus difficile pour les Montois de se ravitailler sans perdre des troupes.

                    En 1433, un nouvel incendie détruit une partie de la ville et les Anglais en profitent et attaquent le 17 juin 1434. Cette attaque est un échec total pour les Anglais qui sont repoussés par les montois et qui sont obligés de lever le blocus. Les Anglais resteront cependant dans les forteresses de Tombelaine jusqu'à la libération de la normandie en 1450.
                </p>

                <h3  id="chap5">5. Le Mont, une prison</h3>
                <p>
                    Après ces années de chaos, le prestige de l’abbaye ne cesse de décroître, a tel point que l’on commence a transformer le lieu de pèlerinage en prison.
                    Le Mont deviendra une prison d’Etat sous le règne de Louis XI. Les moines ne respectent plus les mœurs (certains ont une femme et des enfants) ce qui pousse les différents rois de France à utiliser le Mont uniquement comme une prison et il prend même le nom de “bastille des mers”.

                    Cependant, ce titre de prison d’Etat a probablement permis que l’on puisse aujourd’hui visiter le Mont-Saint-Michel. En effet, en 1789, la plupart des bâtiments religieux tombent en ruine et sont rasés à cause de la Révolution Française.
                    Les derniers moines quittent l’abbaye en 1791 et l’unique vocation du Mont est désormais pénitentiaire. En 1793, plus de 300 prêtres y sont enfermés. Jusqu'à 700 personnes sont retenues prisonnières en même temps et les conditions de vie sont dénoncées par de nombreux auteurs et politiques. Les prisonniers travaillent dans des ateliers installés dans l’abbaye. En 1863, Napoléon III prend la décision de fermer cette prison. Au total, plus de 14 000 prisonniers auront écroué leurs peines entre les remparts du Mont Libre, car c’est ainsi qu’il est appelé durant cette période.
                </p>
                <h3  id="chap6">6. Entre restauration et retour vers la religion</h3>
                <img class="ilu3" src="../img/histoire_3.png">
                <p>
                    D’importants travaux de rénovation commencent dès 1863 et en 1877, un grand rassemblement attire plus de 25 000 pèlerins au Mont.
                    Entre 1878 et 1880, une digue route est construite afin de pouvoir accéder au Mont depuis la terre ferme.
                    Les travaux de rénovation durent jusqu’au début du XXème siècle.
                    En 1922, le culte est restauré dans l’abbaye. En 1966, pour célébrer le millénaire de l’abbaye, de nombreuses communautés de moines bénédictins envoient des moines passer 1 an dans le mont. Certains choisiront de rester après cette année et ils permettent, par leur présence, de redonner à ce lieu le caractère religieux qui lui était initialement attribué.

                    Une explosion du nombre de touristes a lieu dans les années 1960 avec le développement de l’automobile, des congés payés et de la croissance économique du pays.
                    Les moines désertent cependant le mont peu à peu après 1979. Depuis 2001, ils sont remplacés par des frères et soeurs des Fraternités monastiques de Jérusalem. Ils sont présents sur le mont toute l’année.
                </p>

                <h3  id="chap7">7. Le projet Saint-Michel</h3>
                <p>
                    Ce projet qui, en 1990, était appelé “désensablement du Mont” est désormais appelé “restauration du caractère maritime du Mont-Saint-Michel”. L’objectif principal de ce projet est de permettre au mont de conserver son insularité 20 jours par an lors des grandes marées. De plus, l’objectif est de supprimer progressivement les schorres (ou pré-salés) qui se sont formés autour du mont saint michel à cause de l’activité humaine.
                </p>

                    </p>
                    </details>
            </div>
        </section>
        <?php } ?>



        <footer>
            <?php include ('footer.php')?>
        </footer>

        <div id="scroll_to_top"  class="fleche">
            <a href="#top"><img src="../img/top.png" alt="Retourner en haut" /></a>
        </div>

        <script>
             afficher_cacher('texte');
        </script>
    </body>
</html>