<?php
if (isset($_GET['language']) && ($_GET['language']=="en" || $_GET['language']=="fr")) {
    $language = $_GET['language'];
    $_SESSION['language']=$language;
}
elseif(isset($_SESSION['language']) && ($_SESSION['language']=="en" || $_SESSION['language']=="fr")) {
    $language=$_SESSION['language'];
}
else {
    $language = "fr";
}
?>
<!DOCTYPE html>
<html>

    <head>
        <meta charset="UTF-8">
        <title><?php echo(($language=="en") ? "Architecture at Mont"  : "Architecture au Mont");?></title>
        <link rel="stylesheet" type="text/css" href="../css/Architecture.css">
        <link rel="icon" type="image/png" href="../img/logoMSMPetit.png" sizes="16x16">
    </head>
    <body>

        <header>
            <?php include ('header.php')?>

            <div class="begin">
                <h1>Architecture</h1>
            </div>
        </header>
    <?php if($language=="en"){ ?>
        <div class="sommaire">
            <span class="sommaire2"><a href=<?php echo ("../html/index.php?language=".$language) ?>>Home &nbsp </a> >
            <a href=<?php echo ("../html/Culture.php?language=".$language) ?>>&nbsp Culture &nbsp</a>><a href= <?php echo ("../html/Architecture.php?language=".$language) ?>>&nbsp Architecture</a></span>
        </div>

        <section class="rubrique">
            <h3>history of Architecture</h3>
            <img src="../img/architecture_1.jpg">
            <p>The architecture of the mont saint michel is the result of 13 centuries of construction.

                The two main styles present on the mount are Romanesque and Gothic architecture.</p>

            <p>Romanesque architecture:
                Originally, in 965/966, the Italian architect William de Volpiano drew the plans for the abbey. A church and several buildings were then built.

                The Romanesque architecture is characterized by columns with cylindrical arches. These arches are very often surmounted by sculptures of animals or plants.

                The Romanesque architecture is mainly remarkable for the use of stone for the vaults. The walls are covered with frescoes that represent stories of the Christian religion.
                The walls are often very thick to compensate for the weight of the vaults.
                The advantage of this architecture, which the mount will unfortunately notice several times, is the absence of wood in the vaults. This makes it possible, in the event of fire, to limit the damage. In its history, the Mount will suffer several fires which will leave the city in ashes, except for the stone structures. This architectural style is therefore more influenced by technical constraints than by aesthetic choices.</p><img src="../img/HistoireAccueil.jpg">
            <p>Gothic architecture:

                In the 13th century, the Mount was almost completely destroyed in a fire. It will be restored in a Gothic style, which allows for thinner walls, larger windows and therefore much more light.
                The "wonder" of Mont-Saint-Michel is in a Gothic architectural style. From an architectural and aesthetic point of view, it is a feat at the time. Indeed, it seemed difficult, even inconceivable, to build such a beautiful building (both architecturally and aesthetically) that resisted the forces of nature for so long. Moreover, the location was not necessarily easy to access at the time. This made the construction of this UNESCO heritage wonder even more impressive.
            </p>
        </section>
        <?php }else{ ?>


    <div class="sommaire">
            <span class="sommaire2"><a href=<?php echo ("../html/index.php?language=".$language) ?>>Accueil &nbsp </a> >
            <a href=<?php echo ("../html/Culture.php?language=".$language) ?>>&nbsp Culture &nbsp</a>><a href= <?php echo ("../html/Architecture.php?language=".$language) ?>>&nbsp Architecture</a></span>
        </div>
        <section class="rubrique">
            <h3>Histoire de l'Architecture</h3>
            <img src="../img/architecture_1.jpg">
            <p>L’architecture du mont saint michel est le résultat de 13 siècles de construction.

Les deux styles principaux présents sur le mont sont l’architecture Romane et l’architecture Gothique. </p>

<p>L’architecture Romane :
À l’origine, en 965/966, l’architecte italien William de Volpiano dessine les plans de l’abbaye. Une église et plusieurs bâtiments sont alors construits.

L’architecture romane est caractérisée par des colonnes avec des arcs cylindriques. Ces arcs sont très souvent surmontés de sculptures d’animaux ou de plantes.

L'architecture romane est principalement remarquable pour l’utilisation de la pierre pour les voûtes. Les murs sont recouverts de fresques qui représentent des histoires de la religion chrétienne.
    Les murs sont souvent très épais pour palier au poids des voûtes.
    L’avantage de cette architecture, que le mont constatera malheureusement à plusieurs reprises, est l’absence de bois dans les voûtes. Cela permet, en cas d’incendie, de limiter les dégâts. Dans son histoire, le Mont subira plusieurs incendies qui laisseront la ville en cendre, à l'exception des structures en pierre. Ce style architectural est donc plus influencé par des contraintes techniques que par des choix esthétiques.</p>
</p><img src="../img/HistoireAccueil.jpg">
<p>L’architecture Gothique :

Au XIIIème siècle, le Mont est presque intégralement détruit dans un incendie. Il sera restauré dans un style gothique, qui permet d’avoir des mur plus fins, des fenêtres plus grandes et donc beaucoup plus de lumière.
La “merveille” du Mont-Saint-Michel est dans un style architectural Gothique. D’un point de vue architectural et esthétique, c’est un exploit à l'époque. En effet, cela semblait difficile, voir inconcevable, de construire  un bâtiment aussi beau(tant au niveau de l’architecture qu’au niveau esthétique) qui résiste aussi longtemps aux forces de la nature. De plus, l’emplacement n’est pas forcément simple d’accès à l'époque. Cela a rendu la construction de cette merveille du patrimoine de l’UNESCO encore plus impressionnante.
        </p>
        </section>
        <?php }?>


        <footer>
            <?php include ('footer.php')?>
        </footer>

        <div id="scroll_to_top"  class="fleche"> 
            <a href="#top"><img src="../img/top.png" alt="Retourner en haut" /></a> 
        </div>

    </body>
</html>