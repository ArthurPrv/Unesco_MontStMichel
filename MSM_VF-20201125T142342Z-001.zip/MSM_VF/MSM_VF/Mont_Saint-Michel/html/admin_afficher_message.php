<!DOCTYPE html>
<html lang='fr'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Message</title>
    <link rel="stylesheet" type="text/css" href="../css/Contact.css">
</head>
<body>
    <h1>Administration</h1>
    <a href="admin_afficher_contacts.php"><button>Retour</button></a>
    <a href="deconnexion.php"><button>Déconnexion</button></a>
<?php
session_start();
if(!isset($_SESSION['login'])){ 
    header('Location: admin_connexion.html');
    exit;
}
if(!isset($_GET['numContact'])){
    header('Location: admin_afficher_contacts.php');
    exit;
}
include('connexion.php');
$numContact = $_GET['numContact'];
$requete = "Select * From msm_contact Where numContact = $numContact";
$resultat = $dbh->query($requete);

if($ligne=$resultat->fetch()){
   if($ligne['statut']){
        $statut = "Traité";
    }
    else {
        $statut = "Non Traité"; 
    }
                
                echo "Message n°$ligne[numContact] du $ligne[date] : $statut";
                echo "
                <fieldset>
                    <legend>Message</legend>
                    <label for='lastName'>Nom</label>
                    <input type='text' class='disabled' id='lastName' value='$ligne[nom]' disabled>
                    <label for='firstName'>Prénom</label>
                    <input type='text' class='disabled' id='firstName' value='$ligne[prenom]' disabled >
                    <label for='email'>Email</label>
                    <input type='email' class='disabled' name='mail' id='email' value='$ligne[mail]' disabled >
                    <label for='message'>Message</label>
                    <textarea name='message' class='disabled' id='message' disabled>$ligne[message]</textarea>";
                    if($ligne['statut']){
                        echo "<a href='admin_changer_statut.php?numContact=$numContact&statut=0'><button class='orange'>Marquer comme Non Traité</button></a>";
                    }
                    else {
                        echo "<a href='admin_changer_statut.php?numContact=$numContact&statut=1'><button class='green'>Marquer comme Traité</button></a>";
                    }
                    echo "<a href='admin_supprimer_message.php?numContact=$numContact'><button class='orange'>Supprimer le message</button></a>";
                echo "</fieldset>";
}
?>

</body>
</html>