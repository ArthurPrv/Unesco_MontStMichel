<?php
if (isset($_GET['language']) && ($_GET['language']=="en" || $_GET['language']=="fr")) {
    $language = $_GET['language'];
    $_SESSION['language']=$language;
}
elseif(isset($_SESSION['language']) && ($_SESSION['language']=="en" || $_SESSION['language']=="fr")) {
    $language=$_SESSION['language'];
}
else {
    $language = "fr";
}
?>

<!DOCTYPE html>
<html>
    <!-- head -->
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="../css/Groupe.css">
        <link rel="icon" type="image/png" href="../img/logoMSMPetit.png" sizes="16x16">
        <script src="TweenMax.min.js" type="text/javascript"></script> 
        <title>Site du Mont-Saint-Michel</title>
    </head>

    <!-- body -->
    <body>

        <!-- header haut de page -->
        <header>
            <?php include ('header.php')?>
            <div class="begin">
                <h1><?php echo(($language=="en") ? "You are coming"  : "Vous venez"); ?></h1>
            </div>


        </header>
        <?php if($language=="en"){ ?>
            <div class="sommaire">
              <span class="sommaire2"><a href=<?php echo ("../html/index.php?language=".$language) ?>>Home &nbsp </a> >
            <a href=<?php echo ("../html/InfosUtiles.php?language=".$language) ?>>&nbsp Useful Infos</a>><a href= <?php echo ("../html/Groupe.php?language=".$language) ?>>You are coming</a></span>
            </div>

            <section class="rubrique">
                <section id="Famille">

                    <div>
                        <a href="#seul"><img src="../img/Seul.png"  class="rond"width="115%"></a>
                        <p>Alone</p>
                    </div>
                    <div>
                        <a href="#famille"><img src="../img/Groupe.png" class="rond"></a>
                        <p>With Family</p>
                    </div>
                    <div >
                        <a href="#amis"><img src="../img/Groupe.png" class="rond"></a>
                        <p>With Friends</p>
                    </div>
                    <div >
                        <a href="#scolaire"><img src="../img/Couple.png" class="rond"></a>
                        <p>Scolar Group</p>
                    </div>
                </section>
                <h1>Alone or with family:</h1>

                <balise id="seul"><h3>1.Alone:</h3></balise>

                <p>
                    -Free" visit accompanied by visit documents translated into English, German, Italian, Spanish, Russian, Chinese, Dutch, Japanese, Polish, Korean.
                    This type of visit can last from 30 to 1.5 hours.<br>
                    <br>
                    -Guided tours: Translated into French and English all year round, for German, Spanish and Italian only in July and August.
                    Go to the west of the abbey on the terrace.
                    This type of visit lasts 1h15.<br>
                    <br>
                    -Audioguides visits:The audioguides are available in English, French, German, Spanish, Italian, Japanese, Portuguese, Russian, Chinese and Korean.
                    Supplement to the entrance fee: 3 € per person
                    This type of visit lasts 1 hour<br>



                <p>
                    <balise id="famille"><h3>2.Family:</h3> </balise>
                <p>
                    <b>On reservation only</b><br>
                    -Conference" visit: Hours fixed on weekends, school holidays and bridges
                    This type of visit lasts 2 hours.<br>
                    Adult rate: 18 €, Youth rate (7 - 17 years old included) and specific public: 6 €
                    Free for children under 7 years old.<br>
                    <br>
                    Several themes:<br>
                    ->Family visits" /!\ Visit only accessible to families with children aged 7 to 12 years old
                    The history of the abbey with a speech adapted to children will be told to you by a tour guide. Limited to 30 persons<br>
                    <br>
                    ->"Bastille of the Seas"<br>
                    You will discuss the Mont-Saint-Michel prison period and the 
                     Reservation required. Limited to 18 persons<br>
                    <br>
                    ->"A Sunday in the Archangel's Heaven."<br>
                    Visit giving access to the terraces of the choir and the lace staircase if less than 10 people and bad weather.
                    Reservation required. Limited to 18 persons<br>
                <p>
                    <br>




                <h1>FOR GROUPS</h1>
                <p>
                    <b> OBLIGATORY RESERVATION OF A PASSAGE CHANNEL FOR ALL GROUPS</b><br> 
                        (including: prepaid tickets, self-guided tour, tour with independent guide ...)

                </p>

                <balise id="amis"><h3>1.With Friends</h3><balise>

                        <p> Adult group booking form:<a target="_blank" href="http://www.abbaye-mont-saint-michel.fr/Mediatheque/Mediatheque-Mont-Saint-Michel/Formulaire-de-reservation-abbaye-du-Mont-Saint-Michel-groupe-adulte"> Form</a> <br>
                            -Guided tour: No group offer<br>
                            -Visit in autonomy adults : The entrance fee is 9th per person for tourism professionals or for groups with more than 20 members. Visiting documents are available in 12 languages.
                            <br>
                            -Adults conference tour: detailed discovery of the abbey during 2 hours. <br>
                            Package 1 to 30 people: 400 € all included.
                        </p>

                        <balise id="scolaire"><h3>2.Scolar Groups</h3> </balise>

                        <p>
                            For more information, please consult our : <a target="_blank" href=http://www.abbaye-mont-saint-michel.fr/Espace-enseignant>"TEACHER'S AREA"</a>
                        </p>
                        <p>
                            -AHeritage workshops - school groups: Between September and June, workshop visits are available for 2h30.
                            Package from 1 to 35 children: €110 all inclusive (€130 from September 2020).
                            1 Accompanying adult every 15 students is free or any accompanying adult with an Education Pass.<br>
                            A reduced rate is available for holders of a professional education card.<br>
                            Reservation in writing is mandatory, as soon as possible.<br>
                            <br>
                            -Free visit for school groups: fixed price of 30 € (40 € from September 2020) per group of 35 pupils.<br>
                            Reservation in writing (e-mail, mail) is compulsory for school groups and similar.<br>
                            <br>
                            Teachers who are holders of the Education Pass, school assistants and accompanying persons are entitled to free admission within the following limits:<br>
                            nursery school: 1 accompanying adult for every 8 pupils<br>
                            elementary school: 1 accompanying adult for 15 students <br>
                            middle and high schools: 1 accompanying adult for every 15 students <br>
                            <br>
                            Additional accompanying persons (except teachers, school assistants and 18-25 year old EU residents) pay the "group" rate.
                            <br>
                            <br>
                            Teachers who are holders of the Education Pass, duly completed and valid, all benefit from free admission.<br>
                            <br>
                            Teachers without an Education Pass who do not work in France benefit from the reduced rate on presentation of a certificate of practice for the current year.
                            <br>
                            <br>
                            <br>
                            The presence of teachers is mandatory for the entire duration of the visit and they are responsible for their students and their behaviour.
                            We remind you that the presence of the teachers is obligatory for the entire duration of the visit or workshop and that they are responsible for their
                            students and their behaviour.<br>
                            Group packages for thematic visits ::<br>
                            The entrance fee is included in the package.<br>
                            Package 1 to 30 people: 400 € all included.<br>
                            More information on the topics in <a href="#seul"> individual</a>
            </section>
        <?php }else{?>
        <div class="sommaire"> 
            <span class="sommaire2"> <a href=<?php echo ("../html/index.php?language=".$language) ?>>Accueil &nbsp </a> >
            <a href=<?php echo ("../html/InfosUtiles.php?language=".$language) ?>>&nbsp Infos Utiles &nbsp</a>><a href= <?php echo ("../html/Groupe.php?language=".$language) ?>>Vous venez</a></span>
        </div>

        <section class="rubrique">
            <section id="Famille">
                <div>
                    <a href="#seul"><img src="../img/Seul.png" class="rond" width="65%"></a>
                    <p>Tout seul</p>
                </div>
                <div>
                    <a href="#famille"><img src="../img/Groupe.png" class="rond"></a>
                    <p>En Famille</p>
                </div>
                <div >
                    <a href="#amis"><img src="../img/Groupe.png" class="rond"></a>
                    <p>Entre Amis</p>
                </div>
                <div >
                    <a href="#scolaire"><img src="../img/Couple.png" class="rond"></a>
                    <p>Groupe scolaire</p>
                </div>
            </section>
            <h1>Seul ou en famille:</h1>

            <balise id="seul"><h3>1.Seul:</h3></balise>

            <p>
                -Visite "Libre" accompagnée de documents de visite traduits en anglais, allemand, espagnol, russe, chinois, néerlandais, japonais, polonais, coréen.<br>
                Ce type de visite peut durer de 30 min à 1H30.<br>
                <br>
                -Visite "Commentée": traduit en français et anglais toute l'année, pour l'allemand, l'espagnol et l'italien c'est uniquement en juillet et août.<br>
                Rendez vous à l'ouest de l'abbaye sur la terrasse.<br>
                Ce type de visite dure 1h15.<br>
                <br>
                -Visite "Audioguidée". Les audioguides sont disponibles en français, anglais, allemand, espagnol, italien, japonais, portugais, russe, chinois, coréen.<br>
                Supplément au droit d'entrée: 3€ par personne.<br>
                Ce type de visite dure 1h.<br>



            <p>
                <balise id="famille"><h3>2.En famille:</h3> </balise>
            <p>
                <b>Sur reservation uniquement</b><br>
                -Visite "Conférence" Heures fixées les weekends, vacances scolaires et ponts.<br>
                Ce type de visite dure 2h.<br>
                Tarif adulte: 18€, Tarif jeune (7-17ans inclus) et publics spécifiques: 6€<br>
                Gratuit pour les moins de 7 ans.<br>
                <br>
                Plusieurs thématiques:<br>
                ->"Visites familles" /!\ Visite accessible uniquement aux familles avec enfant de 7 à 12 ans.<br>
                L'histoire de l'abbaye avec un discours adapté aux enfants vous sera contée par un guide conférencier. Limitée à 30 personnes.<br>
                <br>
                ->"Bastille des mers"<br>
                Vous aborderez la période carcérale du Mont-Saint-Michel.<br>
                Limitée à 18 personnes.<br>
                <br>
                ->"Un dimanche dans le ciel de l'archange"<br>
                Visite donnant accès aux terrasses du choeur et à l'escalier de dentelle si moins de 10 personnes et en fonction des intempéries.<br>
                Limitée à 18 personnes.<br>
            <p>
                <br>




            <h1>POUR LES GROUPES</h1>
            <p>
                <b> RESERVATION OBLIGATOIRE D'UN CRENAU DE PASSAGE POUR TOUS LES GROUPES</b><br>
                (y compris: billets prépayés, visite libre, visite avec guide indépendant...)
            </p>

            <balise id="amis"><h3>1.Entre Amis</h3><balise>

            <p> Formulaire réservation groupe adulte :<a target="_blank" href="http://www.abbaye-mont-saint-michel.fr/Mediatheque/Mediatheque-Mont-Saint-Michel/Formulaire-de-reservation-abbaye-du-Mont-Saint-Michel-groupe-adulte"> Formulaire</a> <br>
                -Visite commentée: pas d'offre de groupe.<br>
                -Visite en autonomie adultes: le droit d'entrée est de 9€ par personne pour les professionnels du tourisme ou pour des groupes comportant plus de 20 membres. Des documents de visites sont mis à disposition en 12 langues.<br>
                -Visite-conférence adultes: découverte détailléede l'abbaye durant 2h.<br>
                Forfait 1 à 30 personnes: 400€ tout compris.
            </p>

                    <balise id="scolaire"><h3>2.Groupe Scolaire</h3> </balise>

            <p>
                Pour plus d'informations, merci de consulter: <a target="_blank" href=http://www.abbaye-mont-saint-michel.fr/Espace-enseignant>"ESPACE ENSEIGNANT"</a>
            </p>
            <p>
                -Ateliers du patrimoine-groupes scolaires: entre Septembre et Juin, des visites atelier sont disponible pour une durée de 2h30.<br>
                Forfait de 1 à 35 enfants: 110€ tout compris (130€ à partir de Septembre 2020). 1 accompagnateur tous les 15 élèves bénéficie d'une gratuité ou n'importe quelle accompagnateur disposant du Pass Education.<br>
                Un tarif réduit est disponible pour les titulaires d'une carte professionnelle de l'education.<br>
                Réservation par écrit obligatoire, le plus tôt possible.<br>
                <br>
                -Visite libre groupes scolaires: forfait de 30€ (40€ à partir de Septembre 2020) par groupe de 35 élèves.<br>
                Réservation par écrit (mail, courrier) obligatoire pour les groupes scolaires et assimilés.<br>
                <br>
                Les enseignants porteurs du Pass Education, auxiliaires de vie scolaires et accompagnants bénéficient de la gratuité dud roit d'entrée dans les limites suivantes:<br>
                école maternelle: 1 accompagnateur pour 8 élèves <br>
                école élémentaire: 1 accompagnateur pour 15 élèves <br>
                collèges et lycées: 1 accompagnateur pour 15 élèves<br>
                <br>
                Les accompagnants supplémentaires (hors enseignants, auxiliaires de vie scolaires et 18-25 ans résidents UE) payent le tarif "groupe".<br>
                <br>
                Les enseignants porteurs du Pass Education, dûment complété et en cours de validité, bénéficient tous de la gratuité.<br>
                <br>
                Les enseignants sans Pass Education et n'exerçant pas en France, bénéficient du tarif réduit sur présentation d'un certificat d'exercice de l'année en cours.<br>
                <br>
                <br>
                La présence des enseignants est obligatoire toute la durée de la visite et ces derniers sont responsables de leurs élèves et de leurs comportement. Nous vous rappelons que la présence des enseignants est obligatoire toute la durée de la visite ou de l’atelier et qu’ils sont responsables de leurs élèves et de leur comportement.<br>
                Forfaits groupes pour les visites thématiques:<br>
                Le droit d'entrée est inclus dans le forfait.<br>
                Forfait 1 à 30 personnes: 400€ tout compris.<br>
                Plus d'informations sur les thématiques dans Individuels.
        </section>
        <?php } ?>

        <footer>
            <?php include ('footer.php')?>
        </footer>

        <div id="scroll_to_top"  class="fleche"> 
            <a href="#top"><img src="../img/top.png" alt="Retourner en haut" /></a> 
        </div>
    </body>
</html>