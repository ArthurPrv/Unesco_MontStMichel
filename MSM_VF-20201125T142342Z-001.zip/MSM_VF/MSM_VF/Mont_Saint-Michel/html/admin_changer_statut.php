<?php
session_start();
if(!isset($_SESSION['login'])){ 
    header('Location: admin_connexion.html');
    exit;
}
if(!isset($_GET['numContact']) || !isset($_GET['statut'])   ){
    header('Location: admin_afficher_contacts.php');
    exit;
}
$numContact = $_GET['numContact'];
$statut = $_GET['statut'];
$requete = "UPDATE msm_contact Set `statut`  = $statut Where numContact = $numContact";
include('connexion.php');
$dbh->exec($requete);

header("Location: admin_afficher_message.php?numContact=$numContact");
exit;
?>