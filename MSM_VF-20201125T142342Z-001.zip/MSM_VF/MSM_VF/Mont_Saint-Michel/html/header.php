<?php
session_start();
if (isset($_GET['language']) && ($_GET['language']=="en" || $_GET['language']=="fr")) {
    $language = $_GET['language'];
    $_SESSION['language']=$language;
}
elseif(isset($_SESSION['language']) && ($_SESSION['language']=="en" || $_SESSION['language']=="fr")) {
    $language=$_SESSION['language'];
}
else {
    $language = "fr";
}
?>
<header>

            <div class="navbar">
                <a href=<?php echo ("../html/index.php?language=".$language)?>><img class="logo" src="../img/logoMSMPetit.png"></a>
                <nav>
                    <a href=<?php echo ("../html/Histoire.php?language=".$language) ?> class="bloc-couleur bloc-background to-backgound-opacity"><?php echo(($language=="en") ? "History"  : "Histoire"); ?></a>
                    <a href=<?php echo ("../html/Culture.php?language=".$language) ?> class="bloc-couleur bloc-background to-backgound-opacity"><?php echo(($language=="en") ? "Culture" : "Culture"); ?></a>
                    <a href=<?php echo ("InfosUtiles.php?language=".$language) ?> class="bloc-couleur bloc-background to-backgound-opacity"><?php echo(($language=="en") ? "Useful&nbspInfo" : "Infos&nbspUtiles"); ?></a>
                </nav>
                <div class="drapeau">

                    <a href=<?php echo ($_SERVER['PHP_SELF'].(($language=="en") ? "?language=fr" : "?language=en")); ?> ><img <?php echo(($language=="en") ? "src=../img/drapeaufr.png" : "src=../img/ang.png"); ?> ></a>
                </div>
            </div>

