<?php
if (isset($_GET['language']) && ($_GET['language']=="en" || $_GET['language']=="fr")) {
    $language = $_GET['language'];
    $_SESSION['language']=$language;
}
elseif(isset($_SESSION['language']) && ($_SESSION['language']=="en" || $_SESSION['language']=="fr")) {
    $language=$_SESSION['language'];
}
else {
    $language = "fr";
}
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>
            <?php echo(($language=="en") ? "Who Are We" : "Qui sommes nous"); ?>
        </title>
        <link rel="icon" type="image/png" href="../img/logoMSMPetit.png" sizes="16x16">
        <link rel="stylesheet" href="../css/Qsn.css">
    </head>
    <body>
        <header>
            <?php include ('header.php')?>

    <?php if($language=="en"){ ?>
            <div class="titrepage">
                <h1>Who are we?</h1>
            </div>
        </header>

        <section>
            <div class="membres">
                <a class="cadre" target="_blank" href="https://www.linkedin.com/in/gr%C3%A9goire-petetin-a184091b0/"><div>
                        <img class="profil" src="../img/gregoire.jpg">
                        <div class="description">
                            <p>Gregoire PETETIN</p>
                            <p>Role:Group leader<br>Front end Developer<br>Communication Officer</p>
                            <p>Age:18 years old</p>
                        </div>
                    </div></a>
                <a class="cadre" target="_blank" href="https://www.linkedin.com/in/killian-pelletier/"><div>
                        <img class="profilki" src="../img/killian.jpg">
                        <div class="description">
                            <p>Killian PELLETIER</p>
                            <p>Role:Back end Developer<br>Documentalist</p>
                            <p>Age:18 years old</p>
                        </div>
                    </div></a>
                <a class="cadre" target="_blank" href="https://www.linkedin.com/in/thomas-vexiau-7252b41a6/"><div>
                        <img class="profil" src="../img/thomas.jpg">
                        <div class="description">
                            <p>Thomas VEXIAU</p>
                            <p>Role:Back end Developer<br>Documentalist<br>Translator<br>Front end Developer</p>
                            <p>Age:19 years old</p>
                        </div>
                    </div></a>
            </div>
            <div class="membres">
                <a class="cadre" target="_blank" href="https://www.linkedin.com/in/arthur-prevost-3241441a5/"><div>
                        <img class="profil" src="../img/arthur.png">
                        <div class="description">
                            <p>Arthur PREVOST</p>
                            <p>Role:Back end Developer<br>Documentalist<br>Communication Officer</p>
                            <p>Age:18 years old</p>
                        </div>
                    </div></a>
                <a class="cadre" target="_blank" href="https://www.linkedin.com/in/lucas-tripier-b03bbb1a2/"><div>
                        <img class="profil" src="../img/lucas.jpeg">
                        <div class="description">
                            <p>Lucas TRIPIER</p>
                            <p>Role:Front end Developer</p>
                            <p>Age:19 years old</p>
                        </div>
                    </div></a>
            </div>
        </section>
        <?php }else{?>






            <div class="titrepage">
                <h1>Qui sommes nous?</h1>
            </div>
        </header>

        <section>
            <div class="membres">
                <a class="cadre" target="_blank" href="https://www.linkedin.com/in/gr%C3%A9goire-petetin-a184091b0/"><div>
                    <img class="profil" src="../img/gregoire.jpg">
                    <div class="description">
                        <p>Gregoire PETETIN</p>
                        <p>Role:Chef De Groupe<br>Développeur HTML CSS<br>Chargé de communication</p>
                        <p>Age:18 ans</p> 
                    </div>
                </div></a>
                <a class="cadre" target="_blank" href="https://www.linkedin.com/in/killian-pelletier/"><div>
                    <img class="profilki" src="../img/killian.jpg">
                    <div class="description">
                        <p>Killian PELLETIER</p>
                        <p>Role:Développeur PHP<br>Documentaliste</p>
                        <p>Age:18 ans</p> 
                    </div>
                </div></a>
                <a class="cadre" target="_blank" href="https://www.linkedin.com/in/thomas-vexiau-7252b41a6/"><div>
                    <img class="profil" src="../img/thomas.jpg">
                    <div class="description">
                        <p>Thomas VEXIAU</p>
                        <p>Role:Développeur PHP<br>Documentaliste<br>Traducteur<br>Développeur HTML<br></p>
                        <p>Age:19 ans</p> 
                    </div>
                </div></a>
            </div>
            <div class="membres">
                <a class="cadre" target="_blank" href="https://www.linkedin.com/in/arthur-prevost-3241441a5/"><div>
                    <img class="profil" src="../img/arthur.png">
                    <div class="description">
                        <p>Arthur PREVOST</p>
                        <p>Role:Développeur PHP<br>Documentaliste<br>Chargé de communication</p>
                        <p>Age:18 ans</p> 
                    </div>
                </div></a>
                <a class="cadre" target="_blank" href="https://www.linkedin.com/in/lucas-tripier-b03bbb1a2/"><div>
                    <img class="profil" src="../img/lucas.jpeg">
                    <div class="description">
                        <p>Lucas TRIPIER</p>
                        <p>Role:Développeur HTML CSS</p>
                        <p>Age:19 ans</p> 
                    </div>
                </div></a>
            </div>
        </section>
        <?php } ?>
        <footer>
            <?php include ('footer.php')?>
        </footer>

        <div id="scroll_to_top"  class="fleche"> 
            <a href="#top"><img src="../img/top.png" alt="Retourner en haut" /></a> 
        </div>
    </body>
</html>