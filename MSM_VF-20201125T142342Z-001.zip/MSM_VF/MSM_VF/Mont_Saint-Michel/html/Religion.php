<?php
if (isset($_GET['language']) && ($_GET['language']=="en" || $_GET['language']=="fr")) {
    $language = $_GET['language'];
    $_SESSION['language']=$language;
}
elseif(isset($_SESSION['language']) && ($_SESSION['language']=="en" || $_SESSION['language']=="fr")) {
    $language=$_SESSION['language'];
}
else {
    $language = "fr";
}
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title><?php echo(($language=="en") ? "Religion at Mont"  : "Religion au Mont");?></title>
        <link rel="stylesheet" type="text/css" href="../css/Religion.css">
        <link rel="icon" type="image/png" href="../img/logoMSMPetit.png" sizes="16x16">
    </head>
    <body>

        <header>
            <?php include ('header.php')?>





            <div class="begin">
                <h1>Religion</h1>
            </div>
        </header>

        <?php if($language=="en"){ ?>
        <div class="sommaire">
            <span class="sommaire2"><a href=<?php echo ("../html/index.php?language=".$language) ?>>Home &nbsp </a> >
            <a href=<?php echo ("../html/Culture.php?language=".$language) ?>>&nbsp Culture &nbsp</a>><a href= <?php echo ("../html/Religion.php?language=".$language) ?>>&nbsp Religion</a></span>
        </div>

        <section class="rubrique">
            <h3>Religion History</h3>
            <img src="../img/religion1.jpg" class="img">
            <p>
                In 708, Aubert, bishop of Avranches, launched the construction of a sanctuary dedicated to the archangel Michael on Mont-Tombe, now called Mont-Saint-Michel. According to Catholic and Orthodox tradition, the Archangel Michael is the leader of the heavenly militia of the Angels of Good. He is one of the seven major archangels of the Abrahamic religions (Judaism, Christianity and Islam). Tradition tells that the archangel appeared in a dream-vision three times to Aubert to ask him to build a shrine in his name.
                Aubert sent messengers to Monte Gargano, the first known place of worship of the archangel Michael, located in Italy, to bring relics of the archangel to Mont-Tombe (a stone where Saint Michael would have left his foot and a piece of his veil).
                Once built, the sanctuary was officially dedicated to Saint Michael on 16 October 709 and the bishop installed 12 canons.
            </p>
            <p>
                In the year 710, Mont-Tombe takes the name of Mont-Saint-Michel-au-péri. l-de-la-Mer, in reference to the many pilgrims who perish while making the crossing to reach the mountain because of the very fast tides around the Mount.
                During the first century after its construction, the monks, faithful to their mission, transformed this sanctuary into a place of prayer, study and pilgrimage.
                After its construction, the fame of Mont-Saint-Michel continues to grow. Numerous constructions are carried out in order to be able to welcome the pilgrims, who are more and more numerous.
            </p>
            <img src="../img/religion2.png" class="img2">
            <p>In the year 965 or 966, when the development of the riches of the mountain removed the canons from their initial vocation, with the approval of Pope John XIII, the canons of Saint Aubert were replaced by a community of Benedictine monks (who followed the rules of Saint Benedict). It is this year that is chosen for the foundation of the Abbey of Mont-Saint-Michel.

                It was around the year 1000 that the church of Notre-Dame-Sous-Terre was built by these monks. It is, to this day,
                one of the oldest parts of the Mount open to visitors.
            </p>
            <p>
                In 1791, the last Benedictine monks left the mountain. It then becomes a prison where, from 1793, more than 300 priests will be locked up.
                This period led to the dilapidation of the abbey as it was no longer maintained. Living conditions became so difficult that, in 1863, after having seen more than 14,000 prisoners pass through, the remaining prisoners were transferred to the mainland.
            </p>
            <p>
                The abbey was rented to the bishop of Coutances in 1863. 14 years later, on July 3, 1877, the feast of the coronation of the statue of Saint Michael took place in the abbey church. At that time, the Catholic religious authorities were trying with difficulty to reconstitute the sacral power of religion,
                following the radical rejection of religion during the French Revolution. This festival is a success because it gathers no less than 9 bishops, 1 cardinal, 1000 priests and 25 000 pilgrims.
            </p>
            <img src="../img/histoire_3.png" class="img3">
            <p>
                In 1922, worship was restored in the abbey and, after the troubles of the 2nd World War, in 1966, for the millennium of the abbey of Mont-Saint-Michel, many communities of Benedictines sent monks to spend a year on the mountain. A few monks stayed after this year. However, they deserted the Mount in 1979.
                Since 2001, brothers and sisters of the Monastic Fraternities of Jerusalem have been present on the Mount all year round.
            </p>
            <p>
                It is now possible to share the life of the Catholic monks for 1 week, summer and winter,
                in order to pray, live in silence, discover the activities of the monks etc...
            </p>

        </section>


        <?php }else{?>

        <div class="sommaire"> 
            <span class="sommaire2"><a href=<?php echo ("../html/index.php?language=".$language) ?>>Accueil &nbsp </a> >
            <a href=<?php echo ("../html/Culture.php?language=".$language) ?>>&nbsp Culture &nbsp</a>><a href= <?php echo ("../html/Religion.php?language=".$language) ?>>&nbsp Religion</a></span>
        </div>

        <section class="rubrique">
            <h3>Histoire de la religion</h3>
            <img src="../img/religion1.jpg" class="img">
            <p>
                En 708, Aubert, évêque d’Avranches, lance la construction d’un sanctuaire dédié à l’archange Michel sur le Mont-Tombe, aujourd’hui appelé Mont-Saint-Michel. Selon la tradition catholique et orthodoxe, l’archange Michel est le chef de la milice céleste des anges du Bien. Il est l’un des sept archanges majeurs des religions abrahamique (judaïsme, christianisme et islam). La tradition raconte que l’archange est apparu en songe à trois reprises à Aubert pour lui demander de construire un sanctuaire en son nom.
            Aubert envoie des messagers au Monte Gargano, premier lieu de culte connu de l’archange Michel, situé en Italie, afin de ramener des reliques de l’archange sur le Mont-Tombe(une pierre ou Saint-Michel aurait laissé son pied et un morceau de son voile).
            Une fois construit, le sanctuaire est dédié officiellement à Saint Michel le 16 octobre 709 et l'évêque y installe 12 chanoines.
            </p>
            <p>
                En l’an 710, le Mont-Tombe prend le nom de Mont-Saint-Michel-au-péril-de-la-Mer, en référence aux nombreux pèlerins qui périssent en faisant la traversée pour atteindre le mont à cause des marées très rapides autour du Mont.
            Durant le 1er siècle après sa construction, les moines, fidèles à leur mission, transforment ce sanctuaire en lieu de prière, d’étude et de pèlerinage.
            Après sa construction, la renommée du Mont-Saint-Michel ne cesse de croître. De nombreuses constructions sont réalisées afin de pouvoir accueillir les pèlerins, de plus en plus nombreux.
            </p>
            <img src="../img/religion2.png" class="img2">
            <p>En l’an 965 ou 966, alors que le développement des richesses du mont ont écarté les chanoines de leur vocation initiale, avec l’approbation du Pape Jean XIII, les chanoines de Saint Aubert sont remplacés par une communauté de moines bénédictins (qui suivent les règles de Saint Benoît). C’est cette année qui est retenue pour la fondation de l’abbaye du Mont-Saint-Michel.

                C’est vers l’an 1000 que l’église Notre-Dame-Sous-Terre a été édifiée par ces moines. C’est, à ce jour, 
                une des plus anciennes parties du Mont ouverte à la visite.
            </p> 
            <p>
                En 1791, les derniers moines bénédictins quittent le mont. Il devient alors une prison où, dès 1793, plus de 300 prêtres seront enfermés. 
                Cette période entraîne le délabrement de l’abbaye car elle n’est plus entretenue. Les conditions de vie y deviennent tellement difficiles que, en 1863, après avoir vu passer plus de 14 000 prisonniers, les prisonniers restants sont transférés sur le continent.
            </p> 
            <p>
                L’abbaye est louée à l'évêque de Coutances dès 1863. 14 ans plus tard, le 3 juillet 1877, ont lieu les fêtes du couronnement de la statue de Saint Michel dans l'église de l’abbaye. À cette époque, les instances religieuses catholiques essaient avec mal de reconstituer les puissance sacrale de la religion,
                 a la suite du rejet radical de la religion lors de la révolution française. Cette fête est un succès car elle rassemble pas moins de 9 évêques, 1 cardinal, 1000 prêtres et 25 000 pèlerins.
            </p>
            <img src="../img/histoire_3.png" class="img3">
            <p>
                En 1922, le culte est restauré dans l’abbaye et , après les troubles de la 2nde Guerre Mondiale, en 1966, pour le millénaire de l’abbaye du Mont-Saint-Michel, de nombreuses communautés de Bénédictins envoient des moines passer 1 an sur le mont. Quelques moines restent après cette année. Ils désertent cependant le Mont dès l’année 1979. 
                Depuis 2001, des frères et soeurs des Fraternités Monastique de Jérusalem assurent une présence sur le mont toute l’année.
            </p> 
            <p>
                Il est aujourd’hui possible de partager la vie des moines catholiques durant 1 semaine, été comme hiver, 
                afin de prier, vivre en silence, découvrir les activités des moines etc…
            </p>
           
        </section>
        <?php } ?>




        <footer>
            <?php include ('footer.php')?>
        </footer>

        <div id="scroll_to_top"  class="fleche"> 
            <a href="#top"><img src="../img/top.png" alt="Retourner en haut" /></a> 
        </div>


    </body>
</html>